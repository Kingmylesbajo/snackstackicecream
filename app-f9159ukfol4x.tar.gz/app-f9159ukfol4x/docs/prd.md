# Requirements Document

## 1. Application Overview

### 1.1 Application Name
SnackStack Website & Online Ordering System

### 1.2 Application Description
A food ordering and brand website for SnackStack (Tagline: Popped to Perfection!) in The Gambia. The website features B2C food browsing and ordering (cakes, cupcakes, popcorn, ice cream, snacks), customer testimonials and ratings showcase, B2B commercial supplies and equipment showcase, custom cake inquiry submission, preferred fulfillment scheduling, and order tracking with self-service cancellation capability before preparation begins.

## 2. Users & Core Scenarios

### 2.1 Target Users
- Retail Customers (B2C): Browse menu items and customer reviews, place pickup or delivery orders, choose preferred fulfillment time slots, track order status, cancel pending/confirmed orders prior to preparation, or request custom cake quotes.
- Business Clients (B2B): Browse commercial ice cream powders, stabilizers, and soft-serve machines, and access wholesale contact channels.

### 2.2 Core Scenarios
- Customers browse the landing page to view brand offerings, menu items, and customer testimonials with star ratings.
- Customers add retail items to the cart, select fulfillment method (Store Pickup or Delivery), choose an optional fulfillment date and time slot, and submit the order.
- Customers query existing orders by order number and phone number to check live order status and scheduled delivery/pickup time.
- Customers cancel their own order directly from the tracking page when the order is still in Pending or Confirmed status.
- Customers submit custom cake inquiry requests.

## 3. Page Structure & Functional Specifications

### 3.1 Page Structure

```text
SnackStack Website
├── Navigation Bar
├── Home Page Sections
│   ├── Hero Section
│   ├── About Us Section
│   ├── B2C Retail Menu (Cakes, Cupcakes, Treats & Snacks)
│   ├── Customer Testimonials & Ratings Section
│   ├── B2B Commercial Wholesale Section
│   ├── Custom Cake Inquiry Section
│   ├── Track Your Order Section (OrderLookupSection)
│   │   ├── Order Lookup Form (Order Number & Phone Number)
│   │   └── Order Result Card
│   │       ├── Order Status & Progress Indicator
│   │       ├── Order Items & Price Summary
│   │       ├── Fulfillment Details & Scheduled Time
│   │       ├── Cancel Order Button & Confirmation Dialog (for Pending/Confirmed orders)
│   │       └── Wave Refund Contact Notice (for cancelled Wave-paid orders)
│   └── Footer Section
├── Cart & Checkout Drawer (CartSheet)
│   ├── Selected Item List & Quantity Adjustments
│   ├── Price Summary
│   ├── Fulfillment Details Form
│   │   ├── Customer Name & Phone Number
│   │   ├── Fulfillment Type (Store Pickup / Delivery)
│   │   ├── Delivery Address (for Delivery)
│   │   ├── Preferred Fulfillment Date & Time Slot
│   │   └── Order Note
│   ├── Payment Method Selector (Pay on Pickup/Delivery or Wave)
│   └── Order Submit Action
└── Order Success Modal
    ├── Order Number & Summary
    ├── Fulfillment Method & Scheduled Date/Time Slot
    └── Payment & Order Status
```

### 3.2 Functional Specifications

#### 3.2.1 Navigation Bar
- Brand identity: Displays the SnackStack logo and slogan.
- Navigation links: Links to Menu, Reviews, Wholesale, Custom Cake, Track Order, and Contact.
- Quick action: Order Now button and cart trigger icon showing current item count.

#### 3.2.2 Hero & About Sections
- Hero Banner: Displays core brand headline, subheadline, and signature product visuals.
- About Us: Presents brand story, fresh local baking background in The Gambia, and operating hours (Mon-Sat 9:00-20:00, Sun 12:00-20:00).

#### 3.2.3 B2C Retail Menu
- Categories: Big Mold Cakes, Cupcakes, Treats & Snacks (Popcorn, Ice Cream, Popsicles).
- Item Cards: Displays item image, description, flavor/size options, and price in Dalasi (D).
- Add to Cart: Allows choosing quantity and options, then adding to cart.

#### 3.2.4 Customer Testimonials & Ratings Section
- Testimonial Cards: Displays customer reviews highlighting experiences with SnackStack products (cakes, popcorn, and ice cream).
- Review Content: Each review card displays the customer name, star rating (1-5 stars visual representation), and a short testimonial quote.

#### 3.2.5 B2B Commercial Wholesale Section
- Commercial supplies: Displays ice cream flavor powders, stabilizers, and commercial soft-serve machine specifications.
- Business Inquiry: Provides contact details and direct inquiry guidance for wholesale orders.

#### 3.2.6 Custom Cake Inquiry Section
- Inquiry Form: Captures cake size, flavor preference, required date, reference notes/description, customer name, and contact phone number.
- Form Submission: Stores inquiry data to backend for merchant follow-up.

#### 3.2.7 Cart & Checkout Drawer (CartSheet)
- Cart Management: Adjust item quantities (minimum 1, removal on 0), remove items, view real-time subtotal in Gambian Dalasi (D).
- Contact Information: Input fields for Customer Name and Customer Phone Number (required).
- Fulfillment Method: Radio selector between 「Store Pickup」 and 「Delivery」. If Delivery is selected, Address input is required.
- Preferred Fulfillment Schedule:
  - Date Picker: Optional selector for preferred fulfillment date. Disallows past dates.
  - Time Slot Selector: Optional selector for time slot within store business hours (e.g., 9:00-12:00, 12:00-16:00, 16:00-20:00). Sunday slots align with Sunday opening hours (12:00-20:00).
- Order Notes: Optional text area for special instructions.
- Payment Selection: Option to pay On Pickup/Delivery or Pay with Wave.
- Order Submission: Validates form, submits order payload (including preferred date and time slot) to backend storage, and opens Order Success Modal.

#### 3.2.8 Track Your Order & Order Cancellation
- Order Lookup Form: Allows customers to search by Order Number and Phone Number.
- Order Details Display: Displays order status (pending, confirmed, preparing, ready, completed, cancelled), items, total amount, payment status, and scheduled fulfillment date/time.
- Cancel Order Action:
  - Visibility: Displayed on the tracking result card only when the current order status is 「pending」 or 「confirmed」.
  - Confirmation Dialog: Prompts the customer to confirm cancellation before processing.
  - Verification & Execution: Verifies matching phone ownership and cancels the order backend record.
  - State Transition: Upon successful cancellation, updates the result card to reflect the 「cancelled」 state and removes the cancellation button.
  - Refund Instructions: If the cancelled order was paid or in-process via Wave payment, displays a clear instruction to contact the store via WhatsApp for a refund.

#### 3.2.9 Footer Section
- Store Location: Opposite Deeper Life Church & School, Coastal Road, The Gambia.
- Contact Phone: +220 585 4843.
- Email: snackstackicecream@gmail.com.
- Social Link: Instagram (@snackstack_icecream).

## 4. Business Rules & Core Logic

1. Pricing & Currency: All prices are calculated in Gambian Dalasi (D). Total amount equals the sum of item unit prices multiplied by quantities.
2. Cart Quantities: Item quantity cannot be less than 1. Decreasing past 1 removes the item from the cart.
3. Form Validation: Customer Name and Customer Phone are mandatory for checkout. Delivery Address is mandatory only when Fulfillment Method is Delivery.
4. Fulfillment Date & Time Rules: The preferred fulfillment date and time slot are optional for both pickup and delivery. Date selection cannot be earlier than the current date. Time slots are confined within store business hours (Mon-Sat 9:00-20:00, Sun 12:00-20:00).
5. Order Status Lifecycle: Orders follow the progression of pending → confirmed → preparing → ready → completed, or cancelled.
6. Order Cancellation Eligibility: Self-service cancellation is strictly permitted only when the order status is currently 「pending」 or 「confirmed」. Once an order transitions to 「preparing」, 「ready」, or 「completed」, cancellation is disallowed.
7. Cancellation Authentication & Concurrency: Cancellation requests must verify that the submitted phone number matches the order record. If the order status changes to preparing or later before cancellation completes, the cancellation request is rejected.
8. Wave Refund Notice: Cancelling a Wave-paid order does not perform automatic automated banking reversals; it marks the order as cancelled and presents the customer with a direct WhatsApp contact prompt to request refund processing from store staff.

## 5. Exceptions & Edge Cases

| Exception / Edge Case | System Behavior |
| :--- | :--- |
| Cart is empty on checkout | Disable checkout submit button with prompt to add items first |
| Missing required contact or address fields | Highlight missing fields and prevent form submission |
| Past date selected in date picker | Restrict date picker minimum selectable date to current date |
| Order lookup finds no matching record or mismatched phone | Display message indicating no matching order found |
| Order moved to 'preparing' while customer attempts cancellation | Reject cancellation attempt and notify customer that preparation has already started and the order cannot be cancelled |
| Phone number verification mismatch on cancellation | Reject cancellation request and retain current order status |
| Order already cancelled | Render cancelled status state in tracking card with cancellation action hidden |

## 6. Acceptance Criteria

1. The landing page displays a Customer Testimonials & Ratings section featuring customer names, star ratings, and quotes regarding cakes, popcorn, and ice cream.
2. Users can browse menu items, add items to cart, select fulfillment preferences, and submit orders.
3. Users can look up an order using their Order Number and matching Phone Number on the Track Your Order section.
4. When an order is in 'pending' or 'confirmed' status, a \"Cancel Order\" button is visible on the tracking card.
5. Clicking \"Cancel Order\" presents a confirmation dialog before sending the cancellation request.
6. Confirming cancellation updates the order status to 'cancelled' in the backend and immediately updates the tracking card view to show the cancelled state.
7. If the order has already moved to 'preparing', 'ready', or 'completed', the cancellation action is either hidden or rejected with an explanatory message.
8. For cancelled Wave orders, the tracking card displays clear guidance directing the customer to contact store staff on WhatsApp for a refund.

## 7. Out of Scope for Current Release

1. Dynamic public review submission form and direct customer posting moderation system.
2. Automated banking/gateway instant refund integration for Wave payments.
3. Automated live GPS courier tracking on interactive maps.
4. Multi-language localization switching (system strictly in English).