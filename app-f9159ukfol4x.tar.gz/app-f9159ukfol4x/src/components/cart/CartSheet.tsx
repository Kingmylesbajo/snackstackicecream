import React, { useMemo, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { Plus, Minus, Trash2, ShoppingCart, Loader2, MapPin, Store, Wallet, Waves, CalendarDays } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { useCart } from '@/contexts/CartContext';
import { submitOrder, startWaveCheckout } from '@/lib/api';
import { availableSlotsFor } from '@/lib/products';
import OrderSuccessModal, { type CelebrationOrder } from '@/components/cart/OrderSuccessModal';

gsap.registerPlugin(useGSAP);

const prefersReducedMotion = () =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Cart drawer + online order form */
const CartSheet: React.FC = () => {
  const { items, isOpen, closeCart, removeItem, updateQty, clearCart, total } = useCart();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'pickup' | 'delivery'>('pickup');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'wave'>('cash');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredSlot, setPreferredSlot] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [celebration, setCelebration] = useState<CelebrationOrder | null>(null);
  const listRef = useRef<HTMLUListElement>(null);

  // Today in local time, as the minimum selectable date
  const todayISO = useMemo(() => {
    const d = new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }, []);
  const slots = useMemo(
    () => (preferredDate ? availableSlotsFor(preferredDate) : availableSlotsFor(todayISO)),
    [preferredDate, todayISO]
  );
  const isSunday = preferredDate !== '' && new Date(`${preferredDate}T00:00:00`).getDay() === 0;

  // Slide an item out, then actually remove it from cart state
  const removeAnimated = (productId: string, el: HTMLElement | null) => {
    if (prefersReducedMotion() || !el) {
      removeItem(productId);
      return;
    }
    gsap.to(el, {
      autoAlpha: 0,
      x: 64,
      scale: 0.96,
      duration: 0.28,
      ease: 'power2.in',
      onComplete: () => removeItem(productId),
    });
  };

  // Items that have not entered yet (drawer just opened or newly added)
  // cascade in with a springy stagger; already-shown items are skipped
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const fresh = gsap.utils
          .toArray<HTMLElement>('.cart-item')
          .filter((el) => el.dataset.entered !== '1');
        if (fresh.length === 0) return;
        fresh.forEach((el) => {
          el.dataset.entered = '1';
        });
        gsap.fromTo(
          fresh,
          { autoAlpha: 0, x: 64, scale: 0.96 },
          {
            autoAlpha: 1,
            x: 0,
            scale: 1,
            duration: 0.55,
            ease: 'back.out(1.4)',
            stagger: 0.07,
          }
        );
      });
      return () => mm.revert();
    },
    { scope: listRef, dependencies: [items, isOpen] }
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      toast.error('Your cart is empty — add some treats first');
      return;
    }
    if (!customerName.trim() || !customerPhone.trim()) {
      toast.error('Please provide your name and phone number');
      return;
    }
    if (deliveryMethod === 'delivery' && !address.trim()) {
      toast.error('Please enter a delivery address');
      return;
    }
    setSubmitting(true);
    try {
      // Snapshot the cart before clearing it, for the celebration summary
      const snapshotItems = items.map((i) => ({
        name: i.product.name,
        qty: i.qty,
        price: i.product.price,
      }));
      const orderNumber = await submitOrder({
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        delivery_method: deliveryMethod,
        address: deliveryMethod === 'delivery' ? address.trim() : undefined,
        note: note.trim() || undefined,
        items: snapshotItems,
        total,
        payment_method: paymentMethod,
        preferred_date: preferredDate || undefined,
        preferred_time_slot: preferredSlot || undefined,
      });

      // Online payment: create a Wave Checkout session and redirect
      if (paymentMethod === 'wave') {
        try {
          const checkoutUrl = await startWaveCheckout(orderNumber, customerPhone.trim());
          toast.success('Redirecting to Wave to complete your payment...');
          clearCart();
          setCustomerName('');
          setCustomerPhone('');
          setAddress('');
          setNote('');
          setPreferredDate('');
          setPreferredSlot('');
          closeCart();
          window.location.assign(checkoutUrl);
          return;
        } catch (err) {
          // Order is placed — fall back to pay-on-pickup if Wave is unavailable
          toast.error(
            err instanceof Error
              ? err.message
              : 'Wave payment is unavailable — pay on pickup or delivery instead'
          );
        }
      }

      setCelebration({
        orderNumber,
        items: snapshotItems,
        total,
        deliveryMethod,
        customerName: customerName.trim(),
        preferredDate: preferredDate || undefined,
        preferredSlot: preferredSlot || undefined,
      });
      clearCart();
      setCustomerName('');
      setCustomerPhone('');
      setAddress('');
      setNote('');
      setPreferredDate('');
      setPreferredSlot('');
      closeCart();
    } catch {
      toast.error('Submission failed — please check your connection and retry');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Sheet open={isOpen} onOpenChange={closeCart}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-0 overflow-y-auto bg-sidebar p-0 text-sidebar-foreground sm:max-w-md"
      >
        <SheetHeader className="border-b border-sidebar-border px-5 py-4 text-left">
          <SheetTitle className="flex items-center gap-2 font-display text-lg font-bold">
            <ShoppingCart className="h-5 w-5 text-primary" />
            Cart / Order Online
          </SheetTitle>
          <SheetDescription>Review your items, add contact details and place your order</SheetDescription>
        </SheetHeader>

        {/* Item list */}
        <div className="flex-1 px-5 py-4">
          {items.length === 0 ? (
            <div className="flex h-full min-h-40 flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-sidebar-border p-8 text-center text-muted-foreground">
              <ShoppingCart className="h-10 w-10 opacity-40" />
              <p className="text-sm">Your cart is empty</p>
              <Button
                variant="ghost"
                className="border border-primary/50 text-primary hover:bg-primary/10"
                onClick={closeCart}
              >
                Browse Treats
              </Button>
            </div>
          ) : (
            <ul ref={listRef} className="space-y-3">
              {items.map((i) => (
                <li
                  key={i.product.id}
                  className="cart-item flex gap-3 rounded-xl border border-sidebar-border bg-card p-3"
                >
                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-lg">
                    <img
                      src={i.product.image}
                      alt={i.product.name}
                      className="h-full w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <span className="truncate text-sm font-semibold text-foreground">
                        {i.product.name}
                      </span>
                      <button
                        onClick={(e) =>
                          removeAnimated(i.product.id, e.currentTarget.closest('li'))
                        }
                        className="shrink-0 text-muted-foreground transition-colors hover:text-accent"
                        aria-label={`Remove ${i.product.name}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-1">
                      <div className="flex items-center gap-1 rounded-full border border-sidebar-border px-1 py-0.5">
                        <button
                          onClick={(e) => {
                            if (i.qty <= 1) {
                              // Decreasing the last unit removes the item — animate it out
                              removeAnimated(i.product.id, e.currentTarget.closest('li'));
                              return;
                            }
                            updateQty(i.product.id, i.qty - 1);
                          }}
                          className="flex h-6 w-6 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span
                          data-qty
                          className="w-6 text-center text-sm font-bold text-foreground"
                        >
                          {i.qty}
                        </span>
                        <button
                          onClick={(e) => {
                            updateQty(i.product.id, i.qty + 1);
                            if (prefersReducedMotion()) return;
                            // Pop the quantity number when it increases
                            const span = e.currentTarget.closest('li')?.querySelector('[data-qty]');
                            if (span) {
                              gsap.fromTo(span, { scale: 1.4 }, { scale: 1, duration: 0.35, ease: 'back.out(3)' });
                            }
                          }}
                          className="flex h-6 w-6 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                          aria-label="Increase quantity"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <span className="font-display text-sm font-black text-primary">
                        D{i.product.price * i.qty}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Checkout form */}
        {items.length > 0 && (
          <form onSubmit={handleSubmit} className="border-t border-sidebar-border px-5 py-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total (Gambian Dalasi)</span>
              <span className="font-display text-2xl font-black text-primary">D{total}</span>
            </div>

            <Separator className="my-4" />

            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="order-name">
                    Contact Name <span className="text-accent">*</span>
                  </Label>
                  <Input
                    id="order-name"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Your name"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="order-phone">
                    Phone Number <span className="text-accent">*</span>
                  </Label>
                  <Input
                    id="order-phone"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+220 ..."
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Fulfillment</Label>
                <RadioGroup
                  value={deliveryMethod}
                  onValueChange={(v) => setDeliveryMethod(v as 'pickup' | 'delivery')}
                  className="flex gap-4"
                >
                  <label className="flex min-h-12 flex-1 cursor-pointer items-center gap-2 rounded-lg border border-sidebar-border px-3">
                    <RadioGroupItem value="pickup" />
                    <Store className="h-4 w-4 text-primary" />
                    <span className="text-sm">Store Pickup</span>
                  </label>
                  <label className="flex min-h-12 flex-1 cursor-pointer items-center gap-2 rounded-lg border border-sidebar-border px-3">
                    <RadioGroupItem value="delivery" />
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="text-sm">Delivery</span>
                  </label>
                </RadioGroup>
              </div>

              {deliveryMethod === 'delivery' && (
                <div className="space-y-1.5">
                  <Label htmlFor="order-address">
                    Delivery Address <span className="text-accent">*</span>
                  </Label>
                  <Input
                    id="order-address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Street, landmark or neighborhood"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="order-date">Preferred Date &amp; Time (optional)</Label>
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    id="order-date"
                    type="date"
                    value={preferredDate}
                    min={todayISO}
                    onChange={(e) => {
                      const d = e.target.value;
                      setPreferredDate(d);
                      // Drop a slot that is not offered on the newly chosen day
                      if (d && preferredSlot && !availableSlotsFor(d).some((s) => s.value === preferredSlot)) {
                        setPreferredSlot('');
                      }
                    }}
                  />
                  <Select
                    value={preferredSlot || undefined}
                    onValueChange={(v) => setPreferredSlot(v)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Any time" />
                    </SelectTrigger>
                    <SelectContent>
                      {slots.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {isSunday && (
                  <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <CalendarDays className="h-3.5 w-3.5 text-primary" />
                    Sundays we open at 12:00 — morning slot unavailable
                  </p>
                )}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="order-note">Note</Label>
                <Textarea
                  id="order-note"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Flavor preferences, timing, etc. (optional)"
                  rows={2}
                />
              </div>

              <div className="space-y-1.5">
                <Label>Payment</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-lg border px-3 py-2 transition-colors ${
                      paymentMethod === 'cash'
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-sidebar-border text-muted-foreground hover:border-primary/40'
                    }`}
                  >
                    <span className="flex items-center gap-1.5 text-sm font-semibold">
                      <Wallet className="h-4 w-4" />
                      {deliveryMethod === 'delivery' ? 'On Delivery' : 'On Pickup'}
                    </span>
                    <span className="text-[11px] opacity-80">Pay in person</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('wave')}
                    className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-lg border px-3 py-2 transition-colors ${
                      paymentMethod === 'wave'
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-sidebar-border text-muted-foreground hover:border-primary/40'
                    }`}
                  >
                    <span className="flex items-center gap-1.5 text-sm font-semibold">
                      <Waves className="h-4 w-4" />
                      Pay with Wave
                    </span>
                    <span className="text-[11px] opacity-80">Online · secure</span>
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={submitting}
                className="w-full font-display font-bold text-primary-foreground"
              >
                {submitting ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : paymentMethod === 'wave' ? (
                  <Waves className="mr-2 h-5 w-5" />
                ) : (
                  <ShoppingCart className="mr-2 h-5 w-5" />
                )}
                {submitting
                  ? 'Submitting…'
                  : paymentMethod === 'wave'
                    ? `Pay with Wave · D${total}`
                    : `Place Order · D${total}`}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                {paymentMethod === 'wave'
                  ? "You'll be redirected to Wave to complete payment securely."
                  : 'We will call to confirm. Pay in store or on delivery.'}
              </p>
            </div>
          </form>
        )}
      </SheetContent>
      </Sheet>

      {/* Celebration modal with order summary after successful checkout */}
      <OrderSuccessModal order={celebration} onClose={() => setCelebration(null)} />
    </>
  );
};

export default CartSheet;
