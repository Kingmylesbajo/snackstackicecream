import React, { useRef, useState } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { Check, ShoppingBag, MessageCircle, Download, CalendarDays, Facebook } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { downloadReceipt } from '@/lib/receipt';
import { slotLabel } from '@/lib/products';
import type { OrderItem } from '@/types/types';

gsap.registerPlugin(useGSAP);

export interface CelebrationOrder {
  orderNumber: string;
  items: OrderItem[];
  total: number;
  deliveryMethod: 'pickup' | 'delivery';
  customerName: string;
  preferredDate?: string;
  preferredSlot?: string;
}

const WHATSAPP_NUMBER = '2205854843';
const CONFETTI_COUNT = 42;
const CONFETTI_COLORS = ['#FFC107', '#D7263D', '#FAFAF8', '#6B4226'];

/** Interactive celebration modal shown after a successful checkout */
const OrderSuccessModal: React.FC<{
  order: CelebrationOrder | null;
  onClose: () => void;
}> = ({ order, onClose }) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const burstRef = useRef<() => void>(() => {});
  const [downloading, setDownloading] = useState(false);
  const open = !!order;

  const handleDownload = async () => {
    if (!order || downloading) return;
    setDownloading(true);
    try {
      await downloadReceipt(order);
      toast.success('Receipt saved as PDF');
    } catch {
      toast.error('Could not generate the receipt. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  useGSAP(
    (_, contextSafe) => {
      if (!order) return;

      // Confetti burst — reusable so tapping the badge replays it
      const safeContext = contextSafe ?? ((fn: () => void) => fn);
      burstRef.current = safeContext(() => {
        gsap.utils.toArray<HTMLElement>('.confetti-piece').forEach((p) => {
          const angle = gsap.utils.random(-Math.PI * 0.92, -Math.PI * 0.08);
          const dist = gsap.utils.random(80, 210);
          gsap.fromTo(
            p,
            { x: 0, y: 0, autoAlpha: 1, rotation: 0, scale: gsap.utils.random(0.7, 1.2) },
            {
              x: Math.cos(angle) * dist,
              y: Math.sin(angle) * dist,
              rotation: gsap.utils.random(-540, 540),
              duration: 0.7,
              ease: 'power2.out',
            }
          );
          gsap.to(p, {
            y: `+=${gsap.utils.random(150, 280)}`,
            autoAlpha: 0,
            duration: 0.9,
            delay: 0.62,
            ease: 'power1.in',
          });
        });
      });

      const mm = gsap.matchMedia();
      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const tl = gsap.timeline();
        tl.from(
          '.celebrate-badge',
          { scale: 0, rotation: -200, autoAlpha: 0, duration: 0.8, ease: 'elastic.out(1, 0.5)' },
          0.05
        )
          .from(
            '.celebrate-line',
            { y: 24, autoAlpha: 0, stagger: 0.08, duration: 0.5, ease: 'power3.out' },
            0.3
          )
          .from(
            '.summary-row',
            { x: -24, autoAlpha: 0, stagger: 0.06, duration: 0.45, ease: 'power2.out' },
            0.55
          );
        burstRef.current();
      });
      return () => mm.revert();
    },
    { scope: contentRef, dependencies: [order?.orderNumber] }
  );

  const whatsappMessage = order
    ? `Hello SnackStack! I just placed order ${order.orderNumber} (${order.total} D total). Confirming via WhatsApp.`
    : '';

  const shareHref =
    typeof window !== 'undefined'
      ? `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.origin)}`
      : 'https://www.facebook.com/sharer/sharer.php';
  const preferredDateLabel = order?.preferredDate
    ? new Date(`${order.preferredDate}T00:00:00`).toLocaleDateString('en-GB', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
      })
    : '';
  const preferredSlotLabel = slotLabel(order?.preferredSlot);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto bg-card sm:max-w-md [&>button]:z-50">
        <div ref={contentRef} className="relative">
          {/* Confetti layer */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-40 overflow-visible">
            {Array.from({ length: CONFETTI_COUNT }).map((_, i) => (
              <span
                key={i}
                className="confetti-piece absolute left-1/2 top-10 h-2.5 w-1.5 opacity-0"
                style={{ backgroundColor: CONFETTI_COLORS[i % CONFETTI_COLORS.length] }}
              />
            ))}
          </div>

          <DialogHeader className="items-center text-center">
            {/* Tapping the badge replays the confetti burst */}
            <button
              type="button"
              onClick={() => burstRef.current()}
              aria-label="Celebrate again"
              className="celebrate-badge starburst mx-auto mt-2 h-20 w-20 cursor-pointer"
            >
              <Check className="h-9 w-9" strokeWidth={3} />
            </button>
            <DialogTitle className="celebrate-line mt-4 font-display text-2xl font-black text-foreground">
              Order Placed!
            </DialogTitle>
            <DialogDescription className="celebrate-line">
              Thanks {order?.customerName}! We received your order and will call you shortly to confirm.
            </DialogDescription>
          </DialogHeader>

          {/* Order summary */}
          <div className="celebrate-line mt-6 rounded-2xl border border-border bg-background/60 p-5 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Order Reference
              </span>
              <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-display text-xs font-bold tracking-wide text-primary">
                {order?.orderNumber}
              </span>
            </div>

            <Separator className="my-4" />

            <ul className="space-y-2.5">
              {order?.items.map((item) => (
                <li key={item.name} className="summary-row flex items-center justify-between gap-3 text-sm">
                  <span className="min-w-0 flex-1 truncate text-foreground">
                    {item.name} <span className="text-muted-foreground">×{item.qty}</span>
                  </span>
                  <span className="shrink-0 font-display font-bold text-foreground">
                    D{item.price * item.qty}
                  </span>
                </li>
              ))}
            </ul>

            <Separator className="my-4" />

            <div className="summary-row flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                Total · {order?.deliveryMethod === 'delivery' ? 'Delivery' : 'Store Pickup'}
              </span>
              <span className="font-display text-2xl font-black text-primary">D{order?.total}</span>
            </div>

            {(preferredDateLabel || preferredSlotLabel) && (
              <div className="summary-row mt-4 flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-3 py-2.5 text-sm">
                <CalendarDays className="h-4 w-4 shrink-0 text-primary" />
                <span className="min-w-0 text-pretty text-muted-foreground">
                  Preferred:{' '}
                  <span className="font-semibold text-foreground">
                    {preferredDateLabel || 'Any date'}
                    {preferredSlotLabel ? ` · ${preferredSlotLabel}` : ''}
                  </span>
                </span>
              </div>
            )}
          </div>

          <p className="celebrate-line mt-5 text-center text-xs text-muted-foreground">
            Pay in store or on delivery · Tap the gold badge for another celebration
          </p>

          <div className="celebrate-line mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Button
              className="font-display font-bold text-primary-foreground transition-all duration-200 hover:brightness-110 active:scale-[0.98]"
              onClick={onClose}
            >
              <ShoppingBag className="mr-2 h-4 w-4" />
              Continue Shopping
            </Button>
            <Button
              variant="secondary"
              className="border border-border font-display font-bold transition-all duration-200 hover:bg-secondary/80 active:scale-[0.98]"
              onClick={handleDownload}
              disabled={downloading}
            >
              <Download className="mr-2 h-4 w-4" />
              {downloading ? 'Preparing...' : 'Download Receipt'}
            </Button>
            <Button asChild variant="ghost" className="border border-primary/50 text-primary transition-all duration-200 hover:border-primary hover:bg-primary/10 active:scale-[0.98]">
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(whatsappMessage)}`}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle className="mr-2 h-4 w-4" />
                Confirm on WhatsApp
              </a>
            </Button>
            <Button asChild variant="ghost" className="border border-primary/50 text-primary transition-all duration-200 hover:border-primary hover:bg-primary/10 active:scale-[0.98]">
              <a
                href={shareHref}
                target="_blank"
                rel="noreferrer"
              >
                <Facebook className="mr-2 h-4 w-4" />
                Share on Facebook
              </a>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrderSuccessModal;
