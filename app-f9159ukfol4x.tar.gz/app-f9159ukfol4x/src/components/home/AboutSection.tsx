import React from 'react';
import { motion } from 'motion/react';
import { HeartHandshake, Wheat, PartyPopper } from 'lucide-react';
import { BRAND_IMAGES } from '@/lib/products';

const POINTS = [
  {
    icon: Wheat,
    title: 'Baked Fresh Daily',
    desc: 'Everything is baked and made in-store every day with carefully selected ingredients — never overnight.',
  },
  {
    icon: PartyPopper,
    title: 'Party & Event Favorite',
    desc: 'Birthdays, weddings and school events — from a single cupcake to large orders, delivered on time.',
  },
  {
    icon: HeartHandshake,
    title: 'Retail + Wholesale, One Stop',
    desc: 'From one cupcake to a whole case of ice cream ingredients — we have you covered.',
  },
];

/** About section */
const AboutSection: React.FC = () => {
  return (
    <section id="about" className="relative border-t border-border/60 bg-muted/30">
      <div className="mx-auto grid w-full max-w-7xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:px-8 md:py-24">
        {/* Left photo collage (in-store photos) */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto w-full max-w-lg"
        >
          <div className="gold-card overflow-hidden rounded-2xl">
            <div className="aspect-[4/3] w-full overflow-hidden">
              <img
                src={BRAND_IMAGES.moldCakes}
                alt="SnackStack mold cakes: vanilla, chocolate and red velvet"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
          <div className="gold-card absolute -bottom-8 -right-2 w-[46%] rotate-3 overflow-hidden rounded-xl md:-right-6">
            <div className="aspect-square w-full overflow-hidden">
              <img
                src={BRAND_IMAGES.combo}
                alt="Chocolate cake, two-tone ice cream and popcorn combo"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
          <div className="starburst absolute -left-3 -top-5 h-20 w-20 flex-col p-2 text-center md:-left-6">
            <span className="font-display text-[11px] font-black leading-tight">
              Made
              <br />
              with
              <br />
              Love
            </span>
          </div>
        </motion.div>

        {/* Right copy */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            ABOUT US
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black leading-tight text-foreground md:text-4xl">
            The Gambia&rsquo;s <span className="gold-text">Sweet Spot</span>
          </h2>
          <p className="mt-5 max-w-prose text-pretty leading-relaxed text-muted-foreground">
            SnackStack sits along the Coastal Road — a sweet corner locals keep to themselves.
            We believe joy can be stacked: a layer of fluffy cake, a handful of fresh-popped
            popcorn, a swirl of creamy soft serve. Every layer is fresh and made with love.
          </p>

          <ul className="mt-8 space-y-5">
            {POINTS.map((p) => (
              <li key={p.title} className="flex items-start gap-4">
                <span className="starburst mt-0.5 h-11 w-11 shrink-0">
                  <p.icon className="h-5 w-5" strokeWidth={2.2} />
                </span>
                <div>
                  <div className="font-display font-bold text-foreground">{p.title}</div>
                  <div className="mt-1 text-sm leading-relaxed text-muted-foreground">{p.desc}</div>
                </div>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
