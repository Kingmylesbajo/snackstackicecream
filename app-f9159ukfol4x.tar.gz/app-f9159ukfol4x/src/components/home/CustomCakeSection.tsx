import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CakeSlice, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { submitCakeInquiry } from '@/lib/api';
import { BRAND_IMAGES } from '@/lib/products';

const CAKE_SIZES = ['8" (~20cm)', '10" (~25cm)', '12" (~30cm)', 'Two-tier / multi-tier'];
const FLAVORS = ['Vanilla', 'Chocolate', 'Red Velvet', 'Cookies & Cream', 'Caramel', 'Mixed flavors'];

/** Custom cake inquiry form */
const CustomCakeSection: React.FC = () => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [cakeSize, setCakeSize] = useState('');
  const [flavor, setFlavor] = useState('');
  const [neededDate, setNeededDate] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  const validate = (): boolean => {
    const next: { name?: string; phone?: string } = {};
    if (!customerName.trim()) next.name = 'Please enter your name';
    if (!customerPhone.trim()) next.phone = 'Please enter a phone number';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    if (!validate()) {
      toast.error('Please complete the required fields before submitting');
      return;
    }
    setSubmitting(true);
    try {
      const inquiryNumber = await submitCakeInquiry({
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        cake_size: cakeSize || undefined,
        flavor: flavor || undefined,
        needed_date: neededDate || undefined,
        description: description.trim() || undefined,
      });
      toast.success(`Inquiry submitted! Ref ${inquiryNumber} — we will call you shortly with a quote`);
      setCustomerName('');
      setCustomerPhone('');
      setCakeSize('');
      setFlavor('');
      setNeededDate('');
      setDescription('');
    } catch {
      toast.error('Submission failed — please try again or call us directly');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="custom-cake" className="relative scroll-mt-16">
      <div className="mx-auto grid w-full max-w-7xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:px-8 md:py-24">
        {/* Left photo */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto w-full max-w-lg md:order-2"
        >
          <div className="gold-card -rotate-2 overflow-hidden rounded-2xl">
            <div className="aspect-[4/5] w-full overflow-hidden">
              <img
                src={BRAND_IMAGES.cupcakes}
                alt="SnackStack cupcakes: chocolate, vanilla, red velvet and more"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
          <div className="starburst absolute -right-2 -top-6 h-24 w-24 flex-col p-3 text-center md:-right-5">
            <CakeSlice className="mx-auto h-5 w-5" strokeWidth={2.5} />
            <span className="mt-1 font-display text-[10px] font-black leading-tight">
              CUSTOM
              <br />
              CAKES
            </span>
          </div>
        </motion.div>

        {/* Right form */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="md:order-1"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            CUSTOM CAKES
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black text-foreground md:text-4xl">
            Tell Us About <span className="gold-text">Your Dream Cake</span>
          </h2>
          <p className="mt-3 max-w-prose text-pretty text-muted-foreground">
            Share the size, flavor and date you need — our bakers will call you back with a quote.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="cc-name">
                  Your Name <span className="text-accent">*</span>
                </Label>
                <Input
                  id="cc-name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Aminata"
                  className={errors.name ? 'border-accent' : ''}
                />
                {errors.name && <p className="text-xs text-accent">{errors.name}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="cc-phone">
                  Phone Number <span className="text-accent">*</span>
                </Label>
                <Input
                  id="cc-phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+220 ..."
                  className={errors.phone ? 'border-accent' : ''}
                />
                {errors.phone && <p className="text-xs text-accent">{errors.phone}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Cake Size</Label>
                <Select value={cakeSize} onValueChange={setCakeSize}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a size" />
                  </SelectTrigger>
                  <SelectContent>
                    {CAKE_SIZES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Flavor Preference</Label>
                <Select value={flavor} onValueChange={setFlavor}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a flavor" />
                  </SelectTrigger>
                  <SelectContent>
                    {FLAVORS.map((f) => (
                      <SelectItem key={f} value={f}>
                        {f}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cc-date">Date Needed</Label>
              <Input
                id="cc-date"
                type="date"
                value={neededDate}
                onChange={(e) => setNeededDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cc-desc">Special Requests / Details</Label>
              <Textarea
                id="cc-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder='e.g. Two-tier chocolate cake with "Happy Birthday" on top, plus 20 cupcakes…'
                rows={4}
              />
            </div>

            <Button
              type="submit"
              size="lg"
              disabled={submitting}
              className="w-full font-display font-bold text-primary-foreground md:w-auto"
            >
              {submitting ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <Send className="mr-2 h-5 w-5" />
              )}
              {submitting ? 'Submitting…' : 'Submit Inquiry'}
            </Button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default CustomCakeSection;
