import React, { useRef } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { ArrowDown, CakeSlice, Candy, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { PRODUCTS } from '@/lib/products';

gsap.registerPlugin(useGSAP);

/** Hero: staggered entrance + parallax float collage, powered by GSAP */
const Hero: React.FC = () => {
  const { openCart } = useCart();
  const sectionRef = useRef<HTMLElement>(null);
  const collageRef = useRef<HTMLDivElement>(null);

  const chocolateCake = PRODUCTS.find((p) => p.id === 'mold-chocolate');
  const softServe = PRODUCTS.find((p) => p.id === 'treat-softserve');
  const popcorn = PRODUCTS.find((p) => p.id === 'treat-popcorn');

  const scrollToMenu = () => document.querySelector('#menu')?.scrollIntoView({ behavior: 'smooth' });

  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add(
        {
          isAnimated: '(prefers-reduced-motion: no-preference)',
          reduceMotion: '(prefers-reduced-motion: reduce)',
        },
        (context) => {
          const isAnimated = context.conditions?.isAnimated ?? false;

          // 1) Staggered entrance: copy block cascades in, then the collage pops
          if (isAnimated) {
            const tl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } });
            tl.from('.hero-copy-item', { y: 36, autoAlpha: 0, stagger: 0.12 }, 0.1)
              .from(
                '.hero-card-main',
                { y: 56, scale: 0.88, autoAlpha: 0, ease: 'back.out(1.4)', duration: 0.8 },
                0.35
              )
              .from('.hero-card-softserve', { x: -48, autoAlpha: 0, ease: 'back.out(1.6)' }, 0.55)
              .from('.hero-card-popcorn', { x: 48, autoAlpha: 0, ease: 'back.out(1.6)' }, 0.7)
              .from(
                '.hero-badge',
                { scale: 0.3, autoAlpha: 0, ease: 'back.out(2.2)', duration: 0.6 },
                0.9
              );
          }

          // 2) Parallax float: each collage piece drifts on its own sine rhythm
          if (isAnimated) {
            gsap.to('.hero-card-main', {
              y: -14,
              duration: 3.4,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
            });
            gsap.to('.hero-card-softserve', {
              y: -22,
              duration: 4.2,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
              delay: 0.4,
            });
            gsap.to('.hero-card-popcorn', {
              y: -18,
              duration: 3.8,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
              delay: 0.8,
            });
            gsap.to('.hero-badge', {
              y: -10,
              duration: 2.8,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
            });
          }
        }
      );

      // 3) Pointer parallax: collage layers follow the cursor at different depths
      const cards = gsap.utils.toArray<HTMLElement>('.hero-parallax');
      const xTos = cards.map((card) =>
        gsap.quickTo(card, 'x', { duration: 0.9, ease: 'power3.out' })
      );
      const yTos = cards.map((card) =>
        gsap.quickTo(card, 'y', { duration: 0.9, ease: 'power3.out' })
      );
      // Depth factor per layer (further layers move less)
      const depths = [0.03, 0.06, 0.1, 0.14];

      const onPointerMove = (e: PointerEvent) => {
        const rect = collageRef.current?.getBoundingClientRect();
        if (!rect) return;
        const nx = (e.clientX - rect.left) / rect.width - 0.5;
        const ny = (e.clientY - rect.top) / rect.height - 0.5;
        cards.forEach((_, i) => {
          xTos[i](nx * 40 * depths[i]);
          yTos[i](ny * 30 * depths[i]);
        });
      };

      window.addEventListener('pointermove', onPointerMove);
      return () => window.removeEventListener('pointermove', onPointerMove);
    },
    { scope: sectionRef }
  );

  return (
    <section id="home" ref={sectionRef} className="sunburst-bg relative overflow-hidden pt-16">
      {/* Bottom halftone transition */}
      <div className="halftone-bg pointer-events-none absolute inset-x-0 bottom-0 h-40 opacity-60" />

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-12 px-4 pb-20 pt-12 md:grid-cols-2 md:px-8 md:pb-28 md:pt-20">
        {/* Left copy — staggered entrance targets */}
        <div>
          <div className="hero-copy-item inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            Homegrown bakery in The Gambia · POPPED TO PERFECTION!
          </div>

          <h1 className="hero-copy-item mt-6 text-balance font-display text-4xl font-black leading-[1.15] text-foreground md:text-6xl">
            Stack Your <span className="gold-text">Favorite Snacks!</span>
          </h1>

          <p className="hero-copy-item mt-5 max-w-prose text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            The Gambia&rsquo;s home for freshly baked cakes, perfect popcorn and cool ice cream.
            From whole mold cakes to fresh-swirled soft serve — every bite is stacked with joy.
          </p>

          <div className="hero-copy-item mt-8 flex flex-wrap items-center gap-3">
            <Button
              size="lg"
              className="font-display text-base font-bold text-primary-foreground"
              onClick={openCart}
            >
              <Candy className="mr-2 h-5 w-5" />
              Order Now
            </Button>
            <Button
              size="lg"
              variant="ghost"
              className="border border-primary/50 text-primary hover:bg-primary/10"
              onClick={scrollToMenu}
            >
              <ArrowDown className="mr-2 h-5 w-5" />
              Browse the Menu
            </Button>
          </div>

          {/* Quick stats */}
          <div className="hero-copy-item mt-10 grid max-w-md grid-cols-3 gap-4">
            {[
              { num: '8+', label: 'Cupcake flavors' },
              { num: '6+', label: 'Ice cream treats' },
              { num: '100%', label: 'Baked fresh daily' },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-border bg-card/60 px-3 py-3 text-center">
                <div className="font-display text-2xl font-black text-primary">{s.num}</div>
                <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right product collage — parallax float targets */}
        <div ref={collageRef} className="relative mx-auto h-[380px] w-full max-w-md md:h-[480px]">
          {/* Main: chocolate drip cake */}
          <div className="hero-card-main hero-parallax gold-card absolute left-1/2 top-1/2 z-10 w-[62%] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-2xl">
            <div className="aspect-[4/5] w-full overflow-hidden">
              <img
                src={chocolateCake?.image}
                alt="Chocolate drip mold cake"
                className="h-full w-full object-cover"
                loading="eager"
              />
            </div>
            <div className="flex items-center justify-between px-4 py-3">
              <span className="font-display text-sm font-bold text-foreground">Chocolate Drip Cake</span>
              <span className="font-display text-sm font-black text-primary">From D250</span>
            </div>
          </div>

          {/* Top-left: soft serve */}
          <div className="hero-card-softserve hero-parallax gold-card absolute left-0 top-2 z-20 w-[38%] -rotate-6 overflow-hidden rounded-2xl">
            <div className="aspect-square w-full overflow-hidden">
              <img src={softServe?.image} alt="Soft serve ice cream cone" className="h-full w-full object-cover" loading="lazy" />
            </div>
          </div>

          {/* Bottom-right: popcorn */}
          <div className="hero-card-popcorn hero-parallax gold-card absolute bottom-2 right-0 z-20 w-[40%] rotate-6 overflow-hidden rounded-2xl">
            <div className="aspect-square w-full overflow-hidden">
              <img src={popcorn?.image} alt="Signature popcorn bucket" className="h-full w-full object-cover" loading="lazy" />
            </div>
          </div>

          {/* Rotating starburst badge */}
          <div className="hero-badge hero-parallax absolute -right-2 top-6 z-30 md:right-2">
            <div className="starburst badge-spin-slow h-24 w-24 flex-col p-3 text-center">
              <CakeSlice className="mx-auto h-5 w-5" strokeWidth={2.5} />
              <span className="mt-1 font-display text-[10px] font-black leading-tight">
                BAKED
                <br />
                FRESH
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
