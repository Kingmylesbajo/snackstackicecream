import React, { useMemo, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { MENU_CATEGORIES, PRODUCTS } from '@/lib/products';
import type { Product, ProductCategory } from '@/types/types';
import { useCart } from '@/contexts/CartContext';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** Reveal vars shared by scroll-in and filter-change entrances */
const REVEAL = { autoAlpha: 1, y: 0, scale: 1 };
const HIDDEN = { autoAlpha: 0, y: 36, scale: 0.96 };

/** Max tilt angle in degrees on hover */
const MAX_TILT = 10;

/** Single product card — 3D tilt + shadow lift + glossy highlight on hover */
const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const { addItem, openCart } = useCart();
  const [bouncing, setBouncing] = useState(false);
  const bounceTimer = useRef<number | undefined>(undefined);
  const wrapRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const glossRef = useRef<HTMLDivElement>(null);

  const handleAdd = () => {
    addItem(product);
    // Bounce feedback on the Add button
    setBouncing(false);
    window.clearTimeout(bounceTimer.current);
    window.requestAnimationFrame(() => setBouncing(true));
    bounceTimer.current = window.setTimeout(() => setBouncing(false), 500);
    toast.success(`Added to cart: ${product.name}`, {
      action: { label: 'View Cart', onClick: openCart },
    });
  };

  // Hover micro-interactions: tilt follows the cursor, card lifts with a deeper shadow,
  // and a golden gloss tracks the pointer across the surface
  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const card = innerRef.current;
        if (!card) return;

        gsap.set(card, { transformPerspective: 900 });
        const rotXTo = gsap.quickTo(card, 'rotationX', { duration: 0.5, ease: 'power3.out' });
        const rotYTo = gsap.quickTo(card, 'rotationY', { duration: 0.5, ease: 'power3.out' });
        const liftTo = gsap.quickTo(card, 'y', { duration: 0.4, ease: 'power3.out' });

        const onMove = (e: PointerEvent) => {
          const r = card.getBoundingClientRect();
          const nx = (e.clientX - r.left) / r.width - 0.5;
          const ny = (e.clientY - r.top) / r.height - 0.5;
          rotYTo(nx * MAX_TILT);
          rotXTo(-ny * MAX_TILT);
          // Glossy highlight tracks the cursor
          glossRef.current?.style.setProperty('--gx', `${e.clientX - r.left}px`);
          glossRef.current?.style.setProperty('--gy', `${e.clientY - r.top}px`);
        };

        const onEnter = () => {
          liftTo(-8);
          gsap.to(card, {
            boxShadow:
              '0 22px 48px rgba(0, 0, 0, 0.6), 0 0 0 1px hsl(45 100% 51% / 0.4)',
            duration: 0.4,
            ease: 'power2.out',
          });
          gsap.to(glossRef.current, { autoAlpha: 1, duration: 0.35 });
        };

        const onLeave = () => {
          rotXTo(0);
          rotYTo(0);
          liftTo(0);
          gsap.to(card, {
            boxShadow: '0 0 0 1px hsl(45 100% 51% / 0.08), 0 12px 32px rgba(0, 0, 0, 0.45)',
            duration: 0.5,
            ease: 'power2.out',
          });
          gsap.to(glossRef.current, { autoAlpha: 0, duration: 0.35 });
        };

        card.addEventListener('pointermove', onMove);
        card.addEventListener('pointerenter', onEnter);
        card.addEventListener('pointerleave', onLeave);
        return () => {
          card.removeEventListener('pointermove', onMove);
          card.removeEventListener('pointerenter', onEnter);
          card.removeEventListener('pointerleave', onLeave);
        };
      });

      return () => mm.revert();
    },
    { scope: wrapRef }
  );

  return (
    <div ref={wrapRef} className="product-card h-full">
      <div
        ref={innerRef}
        className="gold-card tilt-card relative flex h-full flex-col overflow-hidden rounded-2xl will-change-transform"
      >
        <div className="relative aspect-[4/3] w-full overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
            loading="lazy"
          />
          {product.tag && (
            <span className="absolute left-3 top-3 rounded-full bg-accent px-2.5 py-1 font-display text-[11px] font-bold tracking-wide text-accent-foreground shadow-lg">
              {product.tag}
            </span>
          )}
        </div>

        <div className="flex flex-1 flex-col p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display text-base font-bold leading-snug text-foreground">
              {product.name}
            </h3>
            <span className="starburst h-12 w-12 shrink-0 flex-col text-center">
              <span className="font-display text-[10px] font-black leading-none">
                {product.priceNote ?? `D${product.price}`}
              </span>
            </span>
          </div>
          <p className="mt-1.5 line-clamp-2 text-sm text-pretty text-muted-foreground">{product.desc}</p>

          <div className="mt-auto flex items-center justify-between pt-4">
            <div className="text-xs text-muted-foreground">
              {product.unit && <span>{product.unit} · </span>}
              <span className="font-display text-sm font-black text-primary">
                {product.priceNote ?? `D${product.price}`}
              </span>
            </div>
            <Button
              size="sm"
              className={`font-display font-bold text-primary-foreground ${bouncing ? 'add-bounce' : ''}`}
              onClick={handleAdd}
            >
              <ShoppingCart className="mr-1.5 h-4 w-4" />
              Add
            </Button>
          </div>
        </div>

        {/* Glossy highlight following the cursor */}
        <div
          ref={glossRef}
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-30 opacity-0"
          style={{
            background:
              'radial-gradient(320px circle at var(--gx, 50%) var(--gy, 50%), rgba(255, 236, 180, 0.22), rgba(255, 255, 255, 0.06) 35%, transparent 60%)',
          }}
        />
      </div>
    </div>
  );
};

/** B2C menu section — cards reveal with a smooth stagger as you scroll down */
const MenuSection: React.FC = () => {
  const [category, setCategory] = useState<ProductCategory | 'all'>('all');
  const sectionRef = useRef<HTMLElement>(null);

  const filtered = useMemo(
    () => (category === 'all' ? PRODUCTS : PRODUCTS.filter((p) => p.category === category)),
    [category]
  );

  const activeDesc = MENU_CATEGORIES.find((c) => c.value === category)?.desc;

  // Re-run when the category changes so newly filtered cards animate in again
  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const cards = gsap.utils.toArray<HTMLElement>('.product-card');
        if (cards.length === 0) return;

        gsap.set(cards, HIDDEN);

        // Cards already inside the viewport reveal immediately with a stagger
        const inView = cards.filter(
          (c) => c.getBoundingClientRect().top < window.innerHeight * 0.88
        );
        if (inView.length > 0) {
          gsap.to(inView, { ...REVEAL, duration: 0.65, ease: 'power3.out', stagger: 0.08, overwrite: true });
        }

        // Cards further down reveal in batches as they scroll into view
        ScrollTrigger.batch(cards, {
          start: 'top 88%',
          interval: 0.1,
          once: true,
          onEnter: (batch) =>
            gsap.to(batch, { ...REVEAL, duration: 0.65, ease: 'power3.out', stagger: 0.08, overwrite: true }),
        });
      });

      return () => mm.revert();
    },
    { scope: sectionRef, dependencies: [category], revertOnUpdate: true }
  );

  return (
    <section id="menu" ref={sectionRef} className="relative scroll-mt-16">
      <div className="halftone-bg pointer-events-none absolute inset-x-0 top-0 h-32 opacity-40" />
      <div className="relative mx-auto w-full max-w-7xl px-4 py-16 md:px-8 md:py-24">
        {/* Title */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            OUR MENU
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black text-foreground md:text-4xl">
            Every Bite, <span className="gold-text">Worth Stacking</span>
          </h2>
          <p className="mx-auto mt-3 max-w-prose text-pretty text-muted-foreground">
            {activeDesc} · Everything is made fresh in-store daily
          </p>
        </div>

        {/* Category switcher */}
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {MENU_CATEGORIES.map((c) => {
            const active = category === c.value;
            return (
              <button
                key={c.value}
                onClick={() => setCategory(c.value as ProductCategory | 'all')}
                className={`rounded-full border px-5 py-2.5 font-display text-sm font-bold transition-all ${
                  active
                    ? 'border-primary bg-primary text-primary-foreground shadow-[0_0_18px_hsl(45_100%_51%/0.35)]'
                    : 'border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-primary'
                }`}
              >
                {c.label}
              </button>
            );
          })}
        </div>

        {/* Product grid */}
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-10 rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
            No items in this category yet — check back soon
          </div>
        )}
      </div>
    </section>
  );
};

export default MenuSection;
