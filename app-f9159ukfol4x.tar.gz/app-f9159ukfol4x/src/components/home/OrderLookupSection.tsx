import React, { useRef, useState } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { PackageSearch, Phone, MapPin, ReceiptText, MessageCircle, Clock, CalendarDays, Ban } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { lookupOrder, cancelOrder, type OrderLookupResult } from '@/lib/api';
import { slotLabel } from '@/lib/products';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

gsap.registerPlugin(useGSAP);

// Order progress steps, from received to completed
const STATUS_STEPS = [
  { key: 'pending', label: 'Received', desc: 'Order received — we will call to confirm' },
  { key: 'confirmed', label: 'Confirmed', desc: 'Confirmed with you by phone' },
  { key: 'preparing', label: 'In Preparation', desc: 'Your treats are being made fresh' },
  { key: 'ready', label: 'Ready', desc: 'Ready for pickup or on the way' },
  { key: 'completed', label: 'Completed', desc: 'Enjoyed — thank you!' },
] as const;

const STATUS_BADGES: Record<string, string> = {
  pending: 'bg-primary/15 text-primary border-primary/40',
  confirmed: 'bg-primary/15 text-primary border-primary/40',
  preparing: 'bg-primary/15 text-primary border-primary/40',
  ready: 'bg-accent/15 text-accent border-accent/40',
  completed: 'bg-accent/15 text-accent border-accent/40',
  cancelled: 'bg-accent/15 text-accent border-accent/40',
};

const WHATSAPP_NUMBER = '2205854843';

const PAYMENT_BADGES: Record<string, { label: string; className: string }> = {
  paid: { label: 'Paid', className: 'bg-primary/15 text-primary border-primary/40' },
  awaiting: { label: 'Payment Pending', className: 'bg-muted text-muted-foreground border-border' },
  failed: { label: 'Payment Failed', className: 'bg-accent/15 text-accent border-accent/40' },
};

/** Order status lookup — customers enter their reference + phone number */
const OrderLookupSection: React.FC = () => {
  const [ref, setRef] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<OrderLookupResult | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleCancelOrder = async () => {
    if (!result || cancelling) return;
    setCancelling(true);
    try {
      await cancelOrder(result.order_number, phone.trim());
      setResult({ ...result, status: 'cancelled' });
      toast.success(`Order ${result.order_number} cancelled. We hope to serve you again soon!`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not cancel the order.');
    } finally {
      setCancelling(false);
    }
  };

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setResult(null);
    setLookupError(null);

    if (ref.trim().length < 6) {
      toast.error('Enter your order reference (e.g. SSO261022AB3X)');
      return;
    }
    if (phone.trim().length < 7) {
      toast.error('Enter the phone number you ordered with');
      return;
    }

    setLoading(true);
    try {
      const order = await lookupOrder(ref.trim().toUpperCase(), phone.trim());
      setResult(order);
    } catch (err) {
      setLookupError(err instanceof Error ? err.message : 'Lookup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Reveal the result card with a stagger each time a lookup succeeds
  useGSAP(
    () => {
      if (!result) return;
      const mm = gsap.matchMedia();
      mm.add('(prefers-reduced-motion: no-preference)', () => {
        gsap.from('.lookup-anim', {
          y: 24,
          autoAlpha: 0,
          stagger: 0.08,
          duration: 0.5,
          ease: 'power3.out',
          clearProps: 'all',
        });
      });
      return () => mm.revert();
    },
    { scope: resultRef, dependencies: [result] }
  );

  const stepIndex = result ? STATUS_STEPS.findIndex((s) => s.key === result.status) : -1;
  const isCancelled = result?.status === 'cancelled';
  const cancellable = result?.status === 'pending' || result?.status === 'confirmed';
  const placedOn = result
    ? new Date(result.created_at).toLocaleString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';
  const itemCount = result?.items?.reduce((sum, i) => sum + i.qty, 0) ?? 0;
  const preferredDateLabel = result?.preferred_date
    ? new Date(`${result.preferred_date}T00:00:00`).toLocaleDateString('en-GB', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
      })
    : '';
  const preferredSlotLabel = slotLabel(result?.preferred_time_slot);

  return (
    <section id="track-order" className="relative scroll-mt-16">
      <div className="halftone-bg pointer-events-none absolute inset-x-0 top-0 h-32 opacity-40" />
      <div className="relative mx-auto w-full max-w-3xl px-4 py-16 md:px-8 md:py-24">
        {/* Title */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            ORDER STATUS
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black text-foreground md:text-4xl">
            Track Your <span className="gold-text">Order</span>
          </h2>
          <p className="mx-auto mt-3 max-w-prose text-pretty text-muted-foreground">
            Enter the reference from your order confirmation plus the phone number you ordered
            with.
          </p>
        </div>

        {/* Lookup form */}
        <form
          onSubmit={handleLookup}
          className="gold-card mt-8 rounded-2xl p-5 md:p-6"
        >
          <div className="flex flex-col gap-4 md:flex-row">
            <div className="flex-1">
              <label htmlFor="order-ref" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Order Reference
              </label>
              <Input
                id="order-ref"
                value={ref}
                onChange={(e) => setRef(e.target.value.toUpperCase())}
                placeholder="SSO261022AB3X"
                className="font-display font-bold tracking-wide"
                autoComplete="off"
              />
            </div>
            <div className="flex-1">
              <label htmlFor="order-phone" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Phone Number
              </label>
              <Input
                id="order-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+220 585 4843"
                autoComplete="tel"
              />
            </div>
          </div>
          <Button
            type="submit"
            disabled={loading}
            className="mt-5 w-full font-display font-bold text-primary-foreground"
          >
            <PackageSearch className="mr-2 h-4 w-4" />
            {loading ? 'Checking...' : 'Check Status'}
          </Button>
        </form>

        {/* Lookup error */}
        {lookupError && (
          <div className="mt-6 rounded-2xl border border-accent/40 bg-accent/10 p-5 text-center text-sm text-accent">
            {lookupError}
          </div>
        )}

        {/* Result */}
        {result && (
          <div ref={resultRef} className="gold-card mt-6 rounded-2xl p-5 md:p-6">
            {/* Header: reference + status badge */}
            <div className="lookup-anim flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 font-display text-lg font-black text-foreground">
                <ReceiptText className="h-5 w-5 text-primary" />
                {result.order_number}
              </div>
              <span
                className={`rounded-full border px-3 py-1 font-display text-xs font-bold uppercase tracking-wider ${
                  STATUS_BADGES[result.status] ?? STATUS_BADGES.pending
                }`}
              >
                {result.status}
              </span>
              {result.payment_method === 'wave' && (
                <span
                  className={`rounded-full border px-3 py-1 font-display text-xs font-bold uppercase tracking-wider ${
                    (PAYMENT_BADGES[result.payment_status] ?? PAYMENT_BADGES.awaiting).className
                  }`}
                >
                  {(PAYMENT_BADGES[result.payment_status] ?? PAYMENT_BADGES.awaiting).label}
                </span>
              )}
            </div>

            {/* Meta */}
            <div className="lookup-anim mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="flex items-center gap-2 rounded-xl border border-border bg-background/50 p-3 text-sm">
                <Clock className="h-4 w-4 shrink-0 text-primary" />
                <span className="min-w-0 truncate text-muted-foreground">{placedOn}</span>
              </div>
              <div className="flex items-center gap-2 rounded-xl border border-border bg-background/50 p-3 text-sm">
                <MapPin className="h-4 w-4 shrink-0 text-primary" />
                <span className="min-w-0 truncate text-muted-foreground">
                  {result.delivery_method === 'delivery' ? 'Delivery' : 'Store Pickup'}
                </span>
              </div>
              <div className="flex items-center gap-2 rounded-xl border border-border bg-background/50 p-3 text-sm">
                <Phone className="h-4 w-4 shrink-0 text-primary" />
                <span className="min-w-0 truncate text-muted-foreground">
                  {itemCount} item{itemCount === 1 ? '' : 's'} ·{' '}
                  <span className="font-display font-black text-primary">D{result.total}</span>
                </span>
              </div>
            </div>

            {/* Preferred fulfillment schedule */}
            {(preferredDateLabel || preferredSlotLabel) && (
              <div className="lookup-anim mt-3 flex items-center gap-2 rounded-xl border border-primary/40 bg-primary/10 p-3 text-sm">
                <CalendarDays className="h-4 w-4 shrink-0 text-primary" />
                <span className="min-w-0 text-pretty text-muted-foreground">
                  Preferred{' '}
                  {result.delivery_method === 'delivery' ? 'delivery' : 'pickup'}:{' '}
                  <span className="font-semibold text-foreground">
                    {preferredDateLabel || 'Any date'}
                    {preferredSlotLabel ? ` · ${preferredSlotLabel}` : ''}
                  </span>
                </span>
              </div>
            )}

            {/* Progress timeline */}
            {!isCancelled ? (
              <div className="lookup-anim mt-6">
                <div className="flex flex-col gap-0 md:flex-row md:items-start">
                  {STATUS_STEPS.map((step, i) => {
                    const done = i <= stepIndex;
                    const current = i === stepIndex;
                    return (
                      <div key={step.key} className="flex flex-1 gap-3 md:flex-col md:gap-0">
                        {/* Connector (horizontal on md) */}
                        {i > 0 && (
                          <div
                            className={`hidden h-0.5 flex-1 self-start md:mt-[7px] md:block md:ml-3 ${
                              i <= stepIndex ? 'bg-primary' : 'bg-border'
                            }`}
                          />
                        )}
                        {/* Connector (vertical on mobile) */}
                        {i > 0 && (
                          <div
                            className={`ml-[7px] h-6 w-0.5 md:hidden ${i <= stepIndex ? 'bg-primary' : 'bg-border'}`}
                          />
                        )}
                        <div className="flex items-center gap-3 md:mb-2">
                          <span
                            className={`h-4 w-4 shrink-0 rounded-full border-2 ${
                              done
                                ? 'border-primary bg-primary'
                                : 'border-border bg-card'
                            } ${current ? 'badge-spin-slow' : ''}`}
                          />
                          <div className="min-w-0">
                            <p
                              className={`font-display text-sm font-bold ${
                                done ? 'text-foreground' : 'text-muted-foreground'
                              }`}
                            >
                              {step.label}
                            </p>
                            <p className="text-xs text-muted-foreground">{step.desc}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="lookup-anim mt-6 rounded-xl border border-accent/40 bg-accent/10 p-4 text-sm text-accent">
                This order was cancelled.
                {result.payment_method === 'wave' ? (
                  <>
                    {' '}Paid with Wave? Message us on{' '}
                    <a
                      href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                        `Hello SnackStack! I cancelled my order ${result.order_number} — I would like a Wave refund.`
                      )}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-semibold underline"
                    >
                      <MessageCircle className="h-3.5 w-3.5" />
                      WhatsApp
                    </a>{' '}
                    for a refund.
                  </>
                ) : (
                  ' Contact us if this is unexpected.'
                )}
              </div>
            )}

            {/* Self-service cancellation — only before preparation starts */}
            {cancellable && (
              <div className="lookup-anim mt-6">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      className="w-full border border-accent/60 font-display font-bold text-accent hover:bg-accent/10"
                    >
                      <Ban className="mr-2 h-4 w-4" />
                      Cancel This Order
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="font-display">
                        Cancel order {result.order_number}?
                      </AlertDialogTitle>
                      <AlertDialogDescription>
                        This can't be undone. If you already paid with Wave, message us on WhatsApp
                        afterwards for a refund.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Keep Order</AlertDialogCancel>
                      <AlertDialogAction
                        disabled={cancelling}
                        onClick={handleCancelOrder}
                        className="bg-accent text-accent-foreground hover:bg-accent/90"
                      >
                        {cancelling ? 'Cancelling…' : 'Yes, Cancel Order'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <p className="mt-2 text-center text-xs text-muted-foreground">
                  Available while your order is pending or confirmed — before we start preparing.
                </p>
              </div>
            )}

            <p className="lookup-anim mt-6 text-center text-xs text-muted-foreground">
              Status updated by the store as your order progresses · Questions?{' '}
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                  `Hello SnackStack! I have a question about my order ${result.order_number}.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 font-semibold text-primary hover:underline"
              >
                <MessageCircle className="h-3.5 w-3.5" />
                WhatsApp us
              </a>
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default OrderLookupSection;
