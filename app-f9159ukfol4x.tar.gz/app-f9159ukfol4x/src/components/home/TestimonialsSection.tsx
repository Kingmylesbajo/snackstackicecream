import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

interface Testimonial {
  name: string;
  location: string;
  rating: number;
  quote: string;
  product: string;
}

const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Aminata J.',
    location: 'Brikama',
    rating: 5,
    quote:
      'Ordered a two-tier mold cake for my daughter’s birthday and it was the star of the party. Moist, beautiful and the vanilla flavour was out of this world.',
    product: 'Mold Cake',
  },
  {
    name: 'Lamin S.',
    location: 'Serekunda',
    rating: 5,
    quote:
      'The popcorn is genuinely the best in town — fresh, buttery and never stale. I grab a pack every weekend without fail.',
    product: 'Popcorn',
  },
  {
    name: 'Fatou B.',
    location: 'Kairaba Beach',
    rating: 5,
    quote:
      'Their chocolate ice bar is a childhood dream come true. Creamy vanilla inside that crackling shell — my kids ask for it by name.',
    product: 'Ice Cream',
  },
  {
    name: 'Musa D.',
    location: 'Serrekunda',
    rating: 4,
    quote:
      'Great cupcakes for our office event. Punctual delivery, lovely presentation and the flavours had everyone coming back for seconds.',
    product: 'Cupcakes',
  },
  {
    name: 'Kadiatu T.',
    location: 'Banjul',
    rating: 5,
    quote:
      'Friendly service and the soft serve is so smooth. You can tell everything is made fresh in-store. Highly recommend SnackStack!',
    product: 'Soft Serve',
  },
  {
    name: 'Ousmane K.',
    location: 'Kotu',
    rating: 5,
    quote:
      'I bought the ice cream powder and stabilizer for my own shop. Quality is consistent and the team guided me on exactly what to use.',
    product: 'Wholesale',
  },
];

const OVERALL_RATING = '4.9';
const TOTAL_REVIEWS = '120+';

/** Renders a row of stars for a given rating (1-5) */
const Stars: React.FC<{ rating: number; className?: string }> = ({ rating, className }) => (
  <div className={className} aria-label={`${rating} out of 5 stars`}>
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={
            i < rating
              ? 'h-4 w-4 fill-primary text-primary'
              : 'h-4 w-4 text-muted-foreground/40'
          }
          strokeWidth={2}
        />
      ))}
    </div>
  </div>
);

/** Customer testimonials & ratings section */
const TestimonialsSection: React.FC = () => {
  return (
    <section id="reviews" className="relative border-t border-border/60 bg-background">
      <div className="mx-auto w-full max-w-7xl px-4 py-16 md:px-8 md:py-24">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-primary">
            REVIEWS
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black leading-tight text-foreground md:text-4xl">
            Loved by <span className="gold-text">Sweet Tooths</span> Across The Gambia
          </h2>
          <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
            From birthday cakes to weekend popcorn runs — here’s what our customers keep telling us.
          </p>

          {/* Rating summary */}
          <div className="mt-7 inline-flex items-center gap-4 rounded-2xl border border-border bg-card px-6 py-3 shadow-sm">
            <span className="font-display text-3xl font-black text-primary">{OVERALL_RATING}</span>
            <div className="text-left">
              <Stars rating={5} />
              <p className="mt-1 text-xs text-muted-foreground">Based on {TOTAL_REVIEWS} happy customers</p>
            </div>
          </div>
        </motion.div>

        {/* Testimonial grid */}
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t, idx) => (
            <motion.article
              key={t.name}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: (idx % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="gold-card flex h-full flex-col rounded-2xl p-6"
            >
              <div className="flex items-center justify-between">
                <Stars rating={t.rating} />
                <Quote className="h-7 w-7 text-primary/30" strokeWidth={2} />
              </div>

              <p className="mt-4 flex-1 text-pretty leading-relaxed text-foreground/90">
                &ldquo;{t.quote}&rdquo;
              </p>

              <div className="mt-6 flex items-center gap-3 border-t border-border/70 pt-4">
                <span className="starburst flex h-10 w-10 shrink-0 items-center justify-center font-display text-sm font-black">
                  {t.name.charAt(0)}
                </span>
                <div className="min-w-0">
                  <div className="truncate font-display text-sm font-bold text-foreground">{t.name}</div>
                  <div className="truncate text-xs text-muted-foreground">
                    {t.location} · {t.product}
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
