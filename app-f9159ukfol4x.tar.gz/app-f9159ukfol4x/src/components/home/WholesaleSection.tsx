import React from 'react';
import { motion } from 'motion/react';
import { Check, Phone, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { WHOLESALE_PRODUCTS } from '@/lib/products';

/** B2B wholesale & supply section */
const WholesaleSection: React.FC = () => {
  const goContact = () => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="wholesale" className="relative scroll-mt-16 border-t border-border/60 bg-muted/30">
      <div className="mx-auto w-full max-w-7xl px-4 py-16 md:px-8 md:py-24">
        {/* Title */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-secondary/60 bg-secondary/20 px-4 py-1.5 text-xs font-semibold tracking-wider text-foreground">
            <Building2 className="h-3.5 w-3.5" />
            WHOLESALE / B2B
          </span>
          <h2 className="mt-5 text-balance font-display text-3xl font-black text-foreground md:text-4xl">
            Bring Your Creations <span className="gold-text">to Life!</span>
          </h2>
          <p className="mx-auto mt-3 max-w-prose text-pretty text-muted-foreground">
            Premium food-grade ingredients and commercial equipment for your business —
            ice cream flavor powders, stabilizers and soft serve machines, all in one place.
          </p>
        </div>

        {/* Wholesale grid */}
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2">
          {WHOLESALE_PRODUCTS.map((w, i) => (
            <motion.div
              key={w.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="gold-card flex h-full flex-col overflow-hidden rounded-2xl md:flex-row"
            >
              {/* Photo */}
              <div className="relative aspect-[4/3] w-full shrink-0 overflow-hidden md:aspect-auto md:w-[42%]">
                <img
                  src={w.image}
                  alt={`${w.name} product photo`}
                  className="absolute inset-0 h-full w-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* Info */}
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-lg font-bold text-foreground">{w.name}</h3>
                  <div className="text-right">
                    <div className="font-display text-xl font-black text-primary">{w.price}</div>
                    <div className="text-[11px] text-muted-foreground">{w.unit}</div>
                  </div>
                </div>

                <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">{w.desc}</p>

                <ul className="mt-4 space-y-2">
                  {w.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-foreground">
                      <Check className="h-4 w-4 shrink-0 text-primary" strokeWidth={3} />
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-5">
                  <Button
                    variant="ghost"
                    className="w-full border border-primary/50 text-primary hover:bg-primary/10"
                    onClick={goContact}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Bulk Purchase Inquiry
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Highlights bar */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10 grid grid-cols-2 gap-3 rounded-2xl border border-primary/25 bg-primary/5 p-6 md:grid-cols-4"
        >
          {[
            { k: '24 mo', v: 'Ingredient shelf life' },
            { k: '0.1%+', v: 'Low dosage formulation' },
            { k: 'Door-to-door', v: 'Nationwide Gambia delivery' },
            { k: '1-on-1', v: 'Commercial tech support' },
          ].map((s) => (
            <div key={s.v} className="text-center">
              <div className="font-display text-2xl font-black text-primary">{s.k}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default WholesaleSection;
