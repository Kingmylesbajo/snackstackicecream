import React from 'react';
import { MapPin, Phone, Mail, Facebook, Clock, IceCreamCone } from 'lucide-react';
import { BrandLogo } from './Navbar';

const CONTACTS = [
  {
    icon: MapPin,
    label: 'Store Address',
    value: 'Opposite Deeper Life Church & School, Coastal Road, The Gambia',
    href: undefined,
  },
  { icon: Phone, label: 'Phone / WhatsApp', value: '+220 585 4843', href: 'tel:+2205854843' },
  { icon: Phone, label: 'Backup Phone', value: '+220 326 3063', href: 'tel:+2203263063' },
  {
    icon: Mail,
    label: 'Email',
    value: 'snackstackicecream@gmail.com',
    href: 'mailto:snackstackicecream@gmail.com',
  },
];

/** Footer: contact info and brand details */
const Footer: React.FC = () => {
  return (
    <footer id="contact" className="scroll-mt-16 border-t border-border/60 bg-muted/30">
      <div className="mx-auto w-full max-w-7xl px-4 py-14 md:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-3">
          {/* Brand */}
          <div>
            <BrandLogo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-pretty text-muted-foreground">
              Popped to Perfection! The Gambia&rsquo;s home for freshly baked cakes, perfect popcorn
              and cool ice cream — plus premium ingredients and equipment for food businesses.
            </p>
            <a
              href="https://www.facebook.com/share/1CtERDcmMQ/?mibextid=wwXIfr"
              target="_blank"
              rel="noreferrer"
              className="mt-5 inline-flex items-center gap-2 rounded-full border border-primary/40 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/10"
            >
              <Facebook className="h-4 w-4" />
              SnackStack on Facebook
            </a>
          </div>

          {/* Contacts */}
          <div>
            <h3 className="font-display text-base font-bold text-foreground">Contact Us</h3>
            <ul className="mt-4 space-y-3.5">
              {CONTACTS.map((c) => (
                <li key={c.label} className="flex items-start gap-3">
                  <span className="starburst mt-0.5 h-8 w-8 shrink-0">
                    <c.icon className="h-3.5 w-3.5" strokeWidth={2.5} />
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs text-muted-foreground">{c.label}</div>
                    {c.href ? (
                      <a
                        href={c.href}
                        className="break-words text-sm font-medium text-foreground transition-colors hover:text-primary"
                      >
                        {c.value}
                      </a>
                    ) : (
                      <div className="text-pretty text-sm font-medium text-foreground">{c.value}</div>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Hours + quick links */}
          <div>
            <h3 className="font-display text-base font-bold text-foreground">Opening Hours</h3>
            <div className="mt-4 flex items-start gap-3">
              <span className="starburst mt-0.5 h-8 w-8 shrink-0">
                <Clock className="h-3.5 w-3.5" strokeWidth={2.5} />
              </span>
              <ul className="space-y-1.5 text-sm text-muted-foreground">
                <li>Mon - Sat · 9:00 AM - 8:00 PM</li>
                <li>Sunday · 12:00 PM - 8:00 PM</li>
              </ul>
            </div>

            <h3 className="mt-8 font-display text-base font-bold text-foreground">Quick Links</h3>
            <nav className="mt-4 grid grid-cols-2 gap-2 text-sm">
              {[
                { label: 'Home', hash: '#home' },
                { label: 'Menu', hash: '#menu' },
                { label: 'Wholesale / B2B', hash: '#wholesale' },
                { label: 'Custom Cakes', hash: '#custom-cake' },
              ].map((l) => (
                <button
                  key={l.hash}
                  onClick={() => document.querySelector(l.hash)?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-left text-muted-foreground transition-colors hover:text-primary"
                >
                  {l.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        <div className="dashed-sep mt-12 pt-6 text-center">
          <p className="inline-flex items-center gap-2 text-xs text-muted-foreground">
            <IceCreamCone className="h-3.5 w-3.5 text-primary" />
            © {new Date().getFullYear()} SnackStack · Popped to Perfection! · The Gambia
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
