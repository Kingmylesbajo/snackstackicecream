import React, { useRef, useState } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { ShoppingCart, Menu as MenuIcon, IceCreamCone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useCart } from '@/contexts/CartContext';

gsap.registerPlugin(useGSAP);

const NAV_LINKS = [
  { label: 'Home', hash: '#home' },
  { label: 'Menu', hash: '#menu' },
  { label: 'Reviews', hash: '#reviews' },
  { label: 'Wholesale / B2B', hash: '#wholesale' },
  { label: 'Custom Cakes', hash: '#custom-cake' },
  { label: 'Contact Us', hash: '#contact' },
];

/** Brand logo */
export const BrandLogo: React.FC<{ className?: string }> = ({ className = '' }) => (
  <a href="#home" className={`flex items-center gap-2 ${className}`}>
    <span className="starburst h-9 w-9 shrink-0">
      <IceCreamCone className="h-4 w-4" strokeWidth={2.5} />
    </span>
    <span className="font-display text-xl font-black tracking-tight text-primary">
      SnackStack
      <span className="mt-0.5 block font-sans text-[10px] font-medium tracking-[0.22em] text-muted-foreground">
        POPPED TO PERFECTION!
      </span>
    </span>
  </a>
);

const Navbar: React.FC = () => {
  const { count, openCart } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);
  const iconRef = useRef<HTMLSpanElement>(null);
  const badgeRef = useRef<HTMLSpanElement>(null);
  const pulseRef = useRef<HTMLSpanElement>(null);
  const prevCount = useRef(0);

  // Bounce + pulse the cart icon badge whenever an item is added
  useGSAP(
    () => {
      const increased = count > prevCount.current;
      prevCount.current = count;
      if (!increased) return;

      const mm = gsap.matchMedia();
      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const tl = gsap.timeline();
        tl.fromTo(
          badgeRef.current,
          { scale: 0.3 },
          { scale: 1, duration: 0.7, ease: 'elastic.out(1.2, 0.45)' },
          0
        )
          // Cart icon double-pulse via keyframes
          .to(
            iconRef.current,
            { keyframes: { scale: [1, 1.28, 1, 1.18, 1] }, duration: 0.55, ease: 'power2.inOut' },
            0.05
          )
          // Radar ping ring radiating from the icon
          .fromTo(
            pulseRef.current,
            { scale: 0.7, opacity: 0.8 },
            { scale: 2.1, opacity: 0, duration: 0.6, ease: 'power2.out' },
            0
          );
      });
      return () => mm.revert();
    },
    { dependencies: [count] }
  );

  const goSection = (hash: string) => {
    setMobileOpen(false);
    document.querySelector(hash)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-7xl items-center gap-4 px-4 md:px-8">
        <BrandLogo />

        {/* Desktop nav */}
        <nav className="ml-auto hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <button
              key={l.hash}
              onClick={() => goSection(l.hash)}
              className="rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 md:ml-3">
          {/* Cart entry */}
          <Button
            variant="ghost"
            size="icon"
            className="relative border border-border text-foreground hover:border-primary/60 hover:text-primary"
            onClick={openCart}
            aria-label="Open cart"
          >
            <span ref={iconRef} className="relative flex">
              <ShoppingCart className="h-5 w-5" />
              {/* Radar ping ring, animated on add */}
              <span
                ref={pulseRef}
                aria-hidden="true"
                className="pointer-events-none absolute -inset-1.5 rounded-full border-2 border-accent opacity-0"
              />
            </span>
            {count > 0 && (
              <span
                ref={badgeRef}
                className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] font-bold text-accent-foreground"
              >
                {count}
              </span>
            )}
          </Button>
          <Button
            className="hidden font-display font-bold text-primary-foreground md:inline-flex"
            onClick={openCart}
          >
            Order Now
          </Button>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            className="border border-border text-foreground hover:text-primary md:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation menu"
          >
            <MenuIcon className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-[300px] bg-sidebar text-sidebar-foreground">
          <SheetHeader>
            <SheetTitle className="text-left">
              <BrandLogo />
            </SheetTitle>
          </SheetHeader>
          <nav className="mt-6 flex flex-col gap-1">
            {NAV_LINKS.map((l) => (
              <button
                key={l.hash}
                onClick={() => goSection(l.hash)}
                className="flex min-h-12 items-center rounded-lg px-4 text-left text-base font-medium text-sidebar-foreground transition-colors hover:bg-sidebar-accent"
              >
                {l.label}
              </button>
            ))}
          </nav>
          <Button
            className="mt-6 w-full font-display font-bold text-primary-foreground"
            onClick={() => {
              setMobileOpen(false);
              openCart();
            }}
          >
            Order Now
          </Button>
        </SheetContent>
      </Sheet>
    </header>
  );
};

export default Navbar;
