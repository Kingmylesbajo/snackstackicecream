import { supabase } from '@/db/supabase';
import type { OrderItem } from '@/types/types';

// Reference number: prefix + date + random code
function genNumber(prefix: string): string {
  const d = new Date();
  const ymd = `${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}${ymd}${rand}`;
}

export interface OrderPayload {
  customer_name: string;
  customer_phone: string;
  delivery_method: string;
  address?: string;
  note?: string;
  items: OrderItem[];
  total: number;
  payment_method?: 'cash' | 'wave';
  preferred_date?: string;
  preferred_time_slot?: string;
}

/** Submit an online order */
export async function submitOrder(payload: OrderPayload): Promise<string> {
  const order_number = genNumber('SSO');
  const { error } = await supabase.from('orders').insert({
    order_number,
    customer_name: payload.customer_name,
    customer_phone: payload.customer_phone,
    delivery_method: payload.delivery_method,
    address: payload.address || null,
    note: payload.note || null,
    items: payload.items,
    total: payload.total,
    payment_method: payload.payment_method ?? 'cash',
    preferred_date: payload.preferred_date || null,
    preferred_time_slot: payload.preferred_time_slot || null,
  });
  if (error) throw error;
  return order_number;
}

export interface InquiryPayload {
  customer_name: string;
  customer_phone: string;
  cake_size?: string;
  flavor?: string;
  needed_date?: string;
  description?: string;
}

/** Submit a custom cake inquiry */
export async function submitCakeInquiry(payload: InquiryPayload): Promise<string> {
  const inquiry_number = genNumber('SSC');
  const { error } = await supabase.from('cake_inquiries').insert({
    inquiry_number,
    customer_name: payload.customer_name,
    customer_phone: payload.customer_phone,
    cake_size: payload.cake_size || null,
    flavor: payload.flavor || null,
    needed_date: payload.needed_date || null,
    description: payload.description || null,
  });
  if (error) throw error;
  return inquiry_number;
}

export interface OrderLookupResult {
  order_number: string;
  status: string;
  created_at: string;
  delivery_method: string;
  total: number;
  items: OrderItem[] | null;
  payment_method: string;
  payment_status: string;
  preferred_date: string | null;
  preferred_time_slot: string | null;
}

/** Look up an order's status by reference + the phone number used to order */
export async function lookupOrder(ref: string, phone: string): Promise<OrderLookupResult> {
  const { data, error } = await supabase.functions.invoke('lookup-order', {
    method: 'POST',
    body: { ref, phone },
  });
  if (error) {
    // Surface the edge function's real error message (404 / validation)
    let message = 'Lookup failed. Please try again.';
    try {
      const text = await error.context?.text();
      const parsed = text ? (JSON.parse(text) as { error?: string }) : null;
      if (parsed?.error) message = parsed.error;
    } catch {
      // keep the default message
    }
    throw new Error(message);
  }
  const order = (data as { order?: OrderLookupResult } | null)?.order;
  if (!order) throw new Error('Lookup failed. Please try again.');
  return order;
}

/** Create a Wave Checkout session for a placed order; returns the payment URL */
export async function startWaveCheckout(orderNumber: string, phone: string): Promise<string> {
  const { data, error } = await supabase.functions.invoke('wave-checkout', {
    method: 'POST',
    body: {
      order_number: orderNumber,
      phone,
      origin: window.location.origin,
    },
  });
  if (error) {
    let message = 'Could not start Wave payment. Please try again.';
    try {
      const text = await error.context?.text();
      const parsed = text ? (JSON.parse(text) as { error?: string }) : null;
      if (parsed?.error) message = parsed.error;
    } catch {
      // keep the default message
    }
    throw new Error(message);
  }
  const url = (data as { checkout_url?: string } | null)?.checkout_url;
  if (!url) throw new Error('Could not start Wave payment. Please try again.');
  return url;
}

/** Cancel an order from the tracking page (only while pending/confirmed) */
export async function cancelOrder(ref: string, phone: string): Promise<void> {
  const { error } = await supabase.functions.invoke('cancel-order', {
    method: 'POST',
    body: { ref, phone },
  });
  if (error) {
    let message = 'Could not cancel the order. Please try again.';
    try {
      const text = await error.context?.text();
      const parsed = text ? (JSON.parse(text) as { error?: string }) : null;
      if (parsed?.error) message = parsed.error;
    } catch {
      // keep the default message
    }
    throw new Error(message);
  }
}
