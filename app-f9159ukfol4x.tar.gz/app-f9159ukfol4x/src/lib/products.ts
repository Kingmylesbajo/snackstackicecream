import type { Product, ProductCategory, WholesaleProduct } from '@/types/types';

// Brand photos uploaded by the user (direct CDN URLs)
const U = (name: string) =>
  `https://miaoda-conversation-file.cdn.bcebos.com/user-e0h7uffnbe9s/app-f9159ukfol4x/20261022/${name}.jpg`;

export const BRAND_IMAGES = {
  bananaPowder: U('image_6A52A28A-DFF7-4645-8CE8-0968124302E0'),
  stabilizer: U('image_29A92564-3159-474D-BCDF-F161BAE13D59'),
  flavorCollection: U('image_AC2D7585-20F6-4588-8AC5-46E678535BF7'),
  machine: U('image_184661AA-A192-4927-8AB7-D55599183C94'),
  popcornPack: U('image_43DCF588-8911-4ACC-A457-3BD54DCF84BA'),
  cupcakes: U('image_1CC27B66-1BF4-4050-B507-55DB2DFEF33D'),
  moldCakes: U('image_81D49303-B08B-476A-AC4C-236FD0F588F6'),
  parfait: U('image_76BDC2D3-5CFF-4CCB-9692-B261CB229635'),
  combo: U('image_DDFCE998-0AEB-465A-AB48-9A3E48080F1F'),
};

// Menu category configuration
export const MENU_CATEGORIES: { value: ProductCategory | 'all'; label: string; desc: string }[] = [
  { value: 'all', label: 'All Items', desc: 'Every treat worth stacking on your happy pile' },
  { value: 'mold-cake', label: 'Mold Cakes', desc: 'Vanilla · Chocolate · Red Velvet — happiness by the whole slice' },
  { value: 'cupcake', label: 'Cupcakes', desc: 'One bite, eight moods' },
  { value: 'treat', label: 'Treats & Drinks', desc: 'Popcorn, ice cream and more cool refreshers' },
];

// B2C retail product catalog
export const PRODUCTS: Product[] = [
  // Mold cakes
  {
    id: 'mold-vanilla',
    name: 'Vanilla Mold Cake',
    category: 'mold-cake',
    price: 250,
    priceNote: 'D250 - D350',
    unit: 'Whole mold · from 1kg',
    image: 'https://miaoda-image.cdn.bcebos.com/img/corpus/2148de40e7984e14958371e331d27afd.jpg',
    desc: 'Madagascar vanilla sponge — soft, moist and comforting',
    tag: 'Classic',
  },
  {
    id: 'mold-chocolate',
    name: 'Chocolate Mold Cake',
    category: 'mold-cake',
    price: 250,
    priceNote: 'D250 - D350',
    unit: 'Whole mold · from 1kg',
    image: 'https://miaoda-image.bj.bcebos.com/unsplash_round1/01/unsplash_531646_cISK78NtXSQ.jpg',
    desc: 'Rich chocolate drip glaze — deep cocoa, never too sweet',
    tag: 'Signature',
  },
  {
    id: 'mold-redvelvet',
    name: 'Red Velvet Mold Cake',
    category: 'mold-cake',
    price: 280,
    priceNote: 'D280 - D350',
    unit: 'Whole mold · from 1kg',
    image: 'https://miaoda-image.cdn.bcebos.com/img/corpus/e3793111e4254a65ab7e53941c52a57b.png',
    desc: 'Classic red velvet with cream cheese frosting — a party favorite',
  },
  // Cupcakes
  {
    id: 'cup-chocolate',
    name: 'Chocolate Cupcake',
    category: 'cupcake',
    price: 20,
    unit: 'Each',
    image: 'https://miaoda-image.bj.bcebos.com/pexel_round1/03/pexels_185097_1775285.jpg',
    desc: 'Cocoa sponge topped with chocolate buttercream',
  },
  {
    id: 'cup-vanilla',
    name: 'Vanilla Cupcake',
    category: 'cupcake',
    price: 20,
    unit: 'Each',
    image: 'https://miaoda-image.bj.bcebos.com/pexel_round1/04/pexels_934199_853006.jpg',
    desc: 'Fluffy vanilla buttercream — a kids favorite',
  },
  {
    id: 'cup-redvelvet',
    name: 'Red Velvet Cupcake',
    category: 'cupcake',
    price: 20,
    unit: 'Each',
    image: BRAND_IMAGES.cupcakes,
    desc: 'Red velvet base with cream cheese frosting — shot in-store',
    tag: 'Popular',
  },
  {
    id: 'cup-oreo',
    name: 'Cookies & Cream Cupcake',
    category: 'cupcake',
    price: 25,
    unit: 'Each',
    image: 'https://miaoda-image.bj.bcebos.com/pexel_round1/01/pexels_955049_9979277.jpg',
    desc: 'Crushed cookie filling with swirled cream topping',
  },
  {
    id: 'cup-caramel',
    name: 'Caramel Cupcake',
    category: 'cupcake',
    price: 25,
    unit: 'Each',
    image: 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_0759ad7b-8a57-4219-b1eb-28edcc048282.jpg',
    desc: 'Salted caramel drizzle — sweet with a salty kick',
  },
  // Treats & drinks
  {
    id: 'treat-popcorn',
    name: 'Signature Popcorn',
    category: 'treat',
    price: 50,
    unit: 'Per bucket',
    image: BRAND_IMAGES.popcornPack,
    desc: 'Popped to Perfection! Buttery, crunchy, every single kernel',
    tag: 'Signature',
  },
  {
    id: 'treat-caramel-popcorn',
    name: 'Caramel Popcorn',
    category: 'treat',
    price: 75,
    unit: 'Large bucket',
    image: 'https://miaoda-image.bj.bcebos.com/unsplash_round1/01/unsplash_230021_ocxrJFP0LrE.jpg',
    desc: 'Caramel-coated sharing bucket — a movie night essential',
  },
  {
    id: 'treat-softserve',
    name: 'Soft Serve Cone',
    category: 'treat',
    price: 30,
    unit: 'Per cone',
    image: 'https://miaoda-image.bj.bcebos.com/unsplash_round1/01/unsplash_662762_-YJr_ilK3nY.jpg',
    desc: 'Fresh-swirled soft serve — silky and melt-in-your-mouth',
  },
  {
    id: 'treat-sundae',
    name: 'Ice Cream Sundae',
    category: 'treat',
    price: 60,
    unit: 'Per cup',
    image: 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_0fd7d1e7-34f3-4a59-8012-c984b789fb10.jpg',
    desc: 'Double scoops with chocolate sauce and whipped cream',
  },
  {
    id: 'treat-parfait',
    name: 'Cake Parfait',
    category: 'treat',
    price: 45,
    unit: 'Per cup',
    image: BRAND_IMAGES.parfait,
    desc: 'Layers of cake and ice cream in a cup — shot in-store',
  },
  {
    id: 'treat-icebar',
    name: 'Chocolate Ice Bar',
    category: 'treat',
    price: 25,
    unit: 'Per bar',
    image: 'https://backend.miaoda.online/projects/supabase371307959076040704/storage/v1/object/public/brand-images/icebar-english.jpg',
    desc: 'Vanilla ice cream under a crackling chocolate shell',
  },
];

// B2B wholesale catalog
export const WHOLESALE_PRODUCTS: WholesaleProduct[] = [
  {
    id: 'ws-powder',
    name: 'Ice Cream Flavor Powders',
    image: BRAND_IMAGES.flavorCollection,
    price: 'D850',
    unit: '1000g / bag · case discounts',
    desc: 'Banana, strawberry, caramel, vanilla, chocolate, orange and more. Just 0.1% - 0.5% dosage for professional-grade ice cream.',
    features: ['Full flavor range, in stock', 'Low dosage: 0.1% - 0.5%', '24-month shelf life'],
  },
  {
    id: 'ws-stabilizer',
    name: 'Ice Cream Stabilizer',
    image: BRAND_IMAGES.stabilizer,
    price: 'D1,200',
    unit: '1000g / bag',
    desc: 'Improves texture, boosts creaminess and prevents ice crystals — for both soft and hard ice cream.',
    features: ['Smoother texture & mouthfeel', 'Prevents ice crystallization', 'Works for soft & hard serve'],
  },
  {
    id: 'ws-machine',
    name: 'Soft Serve Machine',
    image: BRAND_IMAGES.machine,
    price: 'D85,000',
    unit: 'Floor-standing, 3 flavors · training included',
    desc: 'Fast freezing, high output, low noise and easy cleaning with a smart digital panel — built for Gambian food businesses.',
    features: ['Fast freeze, high output', 'Smart digital control panel', 'On-site install & training'],
  },
  {
    id: 'ws-popcorn',
    name: 'Branded Popcorn Packs',
    image: BRAND_IMAGES.popcornPack,
    price: 'D35',
    unit: 'Retail packs · white-label ready',
    desc: 'Freshly popped and sealed in branded packs — perfect for shops, cinemas and events. OEM available.',
    features: ['OEM white-label support', 'Cinema & convenience supply', 'Fresh production dates'],
  },
];

/** Fulfillment time slots within store hours (Mon-Sat 9:00-20:00, Sun 12:00-20:00) */
export const TIME_SLOTS = [
  { value: 'morning', label: 'Morning · 9:00 – 12:00' },
  { value: 'afternoon', label: 'Afternoon · 12:00 – 16:00' },
  { value: 'evening', label: 'Evening · 16:00 – 20:00' },
] as const;

export type TimeSlot = (typeof TIME_SLOTS)[number]['value'];

/** Human-readable label for a stored time slot value */
export const slotLabel = (slot: string | null | undefined) =>
  TIME_SLOTS.find((s) => s.value === slot)?.label;

/** Slots available on a given ISO date — the store opens at 12:00 on Sundays */
export const availableSlotsFor = (isoDate: string) => {
  const day = new Date(`${isoDate}T00:00:00`).getDay();
  return day === 0 ? TIME_SLOTS.filter((s) => s.value !== 'morning') : [...TIME_SLOTS];
};
