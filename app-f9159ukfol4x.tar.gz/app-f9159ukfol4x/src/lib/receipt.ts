import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

/** Data needed to render an order receipt PDF */
export interface ReceiptData {
  orderNumber: string;
  items: { name: string; qty: number; price: number }[];
  total: number;
  deliveryMethod: 'pickup' | 'delivery';
  customerName: string;
}

// Brand palette
const GOLD = rgb(1, 0.757, 0.027);
const RED = rgb(0.843, 0.149, 0.239);
const INK = rgb(0.067, 0.067, 0.067);
const GRAY = rgb(0.45, 0.45, 0.45);
const LIGHT = rgb(0.93, 0.93, 0.93);

const PAGE_W = 595;
const PAGE_H = 842;
const MARGIN = 40;
const RIGHT = PAGE_W - MARGIN;

/** Truncate a string so it never overflows its column width */
const fit = (text: string, max: number, size: number, font: { widthOfTextAtSize: (t: string, s: number) => number }) => {
  if (font.widthOfTextAtSize(text, size) <= max) return text;
  let out = text;
  while (out.length > 1 && font.widthOfTextAtSize(`${out}...`, size) > max) {
    out = out.slice(0, -1);
  }
  return `${out}...`;
};

const fmtDate = () => {
  const d = new Date();
  return d.toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

/** Build the SnackStack order receipt and trigger a browser download */
export async function downloadReceipt(order: ReceiptData): Promise<void> {
  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const page = pdfDoc.addPage([PAGE_W, PAGE_H]);

  // ── Gold header band ──
  page.drawRectangle({ x: 0, y: PAGE_H - 72, width: PAGE_W, height: 72, color: GOLD });
  page.drawText('SNACKSTACK', { x: MARGIN, y: PAGE_H - 34, size: 28, font: bold, color: INK });
  page.drawText('Ice Cream & Treats - The Gambia', {
    x: MARGIN,
    y: PAGE_H - 52,
    size: 10,
    font,
    color: INK,
  });

  // ── Title + reference ──
  let y = PAGE_H - 105;
  page.drawText('ORDER RECEIPT', { x: MARGIN, y, size: 16, font: bold, color: INK });
  const ref = order.orderNumber;
  page.drawText(ref, { x: RIGHT - bold.widthOfTextAtSize(ref, 12), y: y + 2, size: 12, font: bold, color: RED });
  y -= 22;

  // ── Meta rows ──
  const meta: [string, string][] = [
    ['Customer', order.customerName],
    ['Fulfillment', order.deliveryMethod === 'delivery' ? 'Delivery' : 'Store Pickup'],
    ['Placed', fmtDate()],
  ];
  meta.forEach(([label, value]) => {
    page.drawText(`${label}:`, { x: MARGIN, y, size: 10, font, color: GRAY });
    page.drawText(value, { x: MARGIN + 70, y, size: 10, font: bold, color: INK });
    y -= 16;
  });

  // ── Items table ──
  y -= 8;
  page.drawRectangle({ x: MARGIN, y: y - 4, width: PAGE_W - MARGIN * 2, height: 20, color: LIGHT });
  const header: [string, number][] = [
    ['ITEM', MARGIN + 6],
    ['QTY', 350],
    ['UNIT PRICE', 415],
    ['LINE TOTAL', RIGHT - 6],
  ];
  header.forEach(([text, x], i) => {
    const w = bold.widthOfTextAtSize(text, 9);
    page.drawText(text, { x: i === 3 ? x - w : x, y: y + 2, size: 9, font: bold, color: INK });
  });
  y -= 26;

  order.items.forEach((item) => {
    page.drawText(fit(item.name, 290, 10, font), { x: MARGIN + 6, y, size: 10, font, color: INK });
    page.drawText(String(item.qty), { x: 350, y, size: 10, font, color: INK });
    page.drawText(`D${item.price}`, { x: 415, y, size: 10, font, color: INK });
    const line = `D${item.price * item.qty}`;
    page.drawText(line, { x: RIGHT - 6 - font.widthOfTextAtSize(line, 10), y, size: 10, font: bold, color: INK });
    y -= 20;
  });

  // ── Total ──
  y -= 6;
  page.drawRectangle({ x: MARGIN, y, width: PAGE_W - MARGIN * 2, height: 28, color: GOLD });
  page.drawText('TOTAL', { x: MARGIN + 6, y: y + 9, size: 13, font: bold, color: INK });
  const total = `D${order.total}`;
  page.drawText(total, {
    x: RIGHT - 6 - bold.widthOfTextAtSize(total, 13),
    y: y + 9,
    size: 13,
    font: bold,
    color: INK,
  });
  y -= 26;
  page.drawText('Payment: pay in store or on delivery.', { x: MARGIN, y, size: 9, font, color: GRAY });

  // ── Store info footer ──
  const infoY = 150;
  page.drawRectangle({ x: MARGIN, y: infoY, width: PAGE_W - MARGIN * 2, height: 1, color: LIGHT });
  const storeLines: [string, number][] = [
    ['SnackStack - Opposite Deeper Life Church & School, Coastal Road, The Gambia', 8],
    ['Phone / WhatsApp: +220 585 4843  |  Email: snackstackicecream@gmail.com', 8],
    ['Hours: Mon-Sat 9:00-20:00  |  Sun 12:00-20:00  |  Facebook: SnackStack', 8],
  ];
  storeLines.forEach(([text, size], i) => {
    page.drawText(text, { x: MARGIN, y: infoY - 18 - i * 14, size, font, color: GRAY });
  });

  const thanks = 'Thank you for stacking with SnackStack!';
  page.drawText(thanks, {
    x: (PAGE_W - bold.widthOfTextAtSize(thanks, 11)) / 2,
    y: 60,
    size: 11,
    font: bold,
    color: INK,
  });

  // ── Trigger browser download ──
  const bytes = await pdfDoc.save();
  const blob = new Blob([bytes as unknown as BlobPart], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `SnackStack-Receipt-${order.orderNumber}.pdf`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
