import React, { useEffect } from 'react';
import { toast } from 'sonner';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CartSheet from '@/components/cart/CartSheet';
import WhatsAppButton from '@/components/common/WhatsAppButton';
import Hero from '@/components/home/Hero';
import AboutSection from '@/components/home/AboutSection';
import MenuSection from '@/components/home/MenuSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import WholesaleSection from '@/components/home/WholesaleSection';
import CustomCakeSection from '@/components/home/CustomCakeSection';
import OrderLookupSection from '@/components/home/OrderLookupSection';

/** SnackStack home page: single-page anchor navigation */
const HomePage: React.FC = () => {
  // Greet customers returning from a Wave payment redirect (?payment=...&ref=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const payment = params.get('payment');
    const ref = params.get('ref');
    if (!payment || !ref) return;
    if (payment === 'success') {
      toast.success(`Payment received for ${ref} — thank you! We will call to confirm your order.`);
    } else {
      toast.error(
        `Payment was not completed for ${ref}. You can retry from Track Your Order below, or pay on pickup / delivery.`
      );
    }
    window.history.replaceState({}, '', window.location.pathname);
  }, []);

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <MenuSection />
        <AboutSection />
        <TestimonialsSection />
        <WholesaleSection />
        <CustomCakeSection />
        <OrderLookupSection />
      </main>
      <Footer />
      <CartSheet />
      <WhatsAppButton />
    </div>
  );
};

export default HomePage;
