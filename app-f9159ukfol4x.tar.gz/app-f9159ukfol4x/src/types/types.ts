// Global type definitions

// B2C product category
export type ProductCategory = 'mold-cake' | 'cupcake' | 'treat';

// B2C retail product
export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  /** Unit price in Gambian Dalasi (D) */
  price: number;
  /** Display price range, e.g. D250 - D350 */
  priceNote?: string;
  /** Pack / portion description */
  unit?: string;
  image: string;
  desc: string;
  tag?: string;
}

// Cart item
export interface CartItem {
  product: Product;
  qty: number;
}

// B2B wholesale product
export interface WholesaleProduct {
  id: string;
  name: string;
  image: string;
  price: string;
  unit: string;
  desc: string;
  features: string[];
}

// Order item (stored in the items jsonb column)
export interface OrderItem {
  name: string;
  qty: number;
  price: number;
}
