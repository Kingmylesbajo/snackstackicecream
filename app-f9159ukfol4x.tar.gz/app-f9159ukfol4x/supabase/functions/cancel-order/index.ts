// Edge Function: cancel-order
// Lets a customer cancel their own order from the tracking page.
// - Ownership is verified with the phone number used to place the order
//   (same digit-suffix match as lookup-order, with generic 404s)
// - The status flip is atomic: the update only matches rows still in
//   'pending' or 'confirmed', so a store that already started preparing
//   the order wins the race and cancellation is refused
// - The orders table is not writable by anon clients (RLS); this function
//   runs with the service role on the customer's behalf

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const CANCELLABLE_STATUSES = ['pending', 'confirmed'];

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const json = (body: unknown, status: number) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });

const digitsOnly = (s: string) => s.replace(/[^0-9]/g, '');

const phonesMatch = (input: string, stored: string) => {
  const a = digitsOnly(input);
  const b = digitsOnly(stored);
  if (a.length < 7 || b.length < 7) return false;
  return a.endsWith(b) || b.endsWith(a);
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  let payload: { ref?: string; phone?: string };
  try {
    payload = await req.json();
  } catch {
    return json({ error: 'Invalid request body' }, 400);
  }

  const ref = (payload.ref ?? '').trim().toUpperCase();
  const phone = (payload.phone ?? '').trim();
  if (ref.length < 6 || ref.length > 32 || phone.length < 7 || phone.length > 32) {
    return json({ error: 'Invalid order reference or phone number.' }, 400);
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  // Ownership check (never reveal whether the reference exists)
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .select('order_number, customer_phone, status')
    .eq('order_number', ref)
    .maybeSingle();

  if (orderError) return json({ error: 'Could not cancel the order. Please try again.' }, 500);
  if (!order || !phonesMatch(phone, order.customer_phone)) {
    return json({ error: 'No order found for that reference and phone number.' }, 404);
  }
  if (order.status === 'cancelled') {
    return json({ error: 'This order is already cancelled.' }, 409);
  }
  if (!CANCELLABLE_STATUSES.includes(order.status)) {
    return json(
      {
        error:
          'Preparation has already started — this order can no longer be cancelled. WhatsApp us if you need help.',
      },
      409
    );
  }

  // Atomic cancellation: only succeeds while still pending/confirmed
  const { data: updated, error: updateError } = await supabase
    .from('orders')
    .update({ status: 'cancelled' })
    .eq('order_number', ref)
    .in('status', CANCELLABLE_STATUSES)
    .select('order_number, status')
    .maybeSingle();

  if (updateError) return json({ error: 'Could not cancel the order. Please try again.' }, 500);
  if (!updated) {
    // The store moved the order forward between our two checks
    return json(
      {
        error:
          'Preparation has already started — this order can no longer be cancelled. WhatsApp us if you need help.',
      },
      409
    );
  }

  return json({ cancelled: true, order_number: updated.order_number, status: updated.status }, 200);
});
