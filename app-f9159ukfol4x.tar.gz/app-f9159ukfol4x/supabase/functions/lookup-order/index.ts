// Edge Function: lookup-order
// Customers verify ownership with their order reference + the phone number they
// ordered with. Phone comparison is digit-normalized so +220 / 00220 / local
// formats all match. Missing orders and phone mismatches return the same
// generic 404 to prevent order enumeration.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const json = (body: unknown, status: number) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });

const digitsOnly = (s: string) => s.replace(/[^0-9]/g, '');

const phonesMatch = (input: string, stored: string) => {
  const a = digitsOnly(input);
  const b = digitsOnly(stored);
  if (a.length < 7 || b.length < 7) return false;
  // One must be a suffix of the other (country-code prefix tolerant)
  return a.endsWith(b) || b.endsWith(a);
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  let payload: { ref?: string; phone?: string };
  try {
    payload = await req.json();
  } catch {
    return json({ error: 'Invalid request body' }, 400);
  }

  const ref = (payload.ref ?? '').trim().toUpperCase();
  const phone = (payload.phone ?? '').trim();
  if (ref.length < 6 || ref.length > 32 || phone.length < 7 || phone.length > 32) {
    return json({ error: 'Please enter a valid order reference and phone number.' }, 400);
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  const { data, error } = await supabase
    .from('orders')
    .select(
      'order_number, customer_phone, status, created_at, delivery_method, total, items, payment_method, payment_status, preferred_date, preferred_time_slot'
    )
    .eq('order_number', ref)
    .maybeSingle();

  if (error) return json({ error: 'Lookup failed. Please try again.' }, 500);

  // Generic response for both "no such order" and "wrong phone"
  if (!data || !phonesMatch(phone, data.customer_phone)) {
    return json({ error: 'No order found for that reference and phone number.' }, 404);
  }

  return json(
    {
      order: {
        order_number: data.order_number,
        status: data.status,
        created_at: data.created_at,
        delivery_method: data.delivery_method,
        total: data.total,
        items: data.items,
        payment_method: data.payment_method,
        payment_status: data.payment_status,
        preferred_date: data.preferred_date,
        preferred_time_slot: data.preferred_time_slot,
      },
    },
    200
  );
});
