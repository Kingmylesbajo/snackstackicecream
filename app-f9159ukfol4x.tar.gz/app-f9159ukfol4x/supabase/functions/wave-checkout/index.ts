// Edge Function: wave-checkout
// Creates a Wave Checkout session for an existing order and returns the
// payment URL the customer is redirected to.
// - The amount is read from the orders row (never trusted from the client)
// - Ownership is verified with the phone number used to place the order
// - WAVE_API_KEY is only ever sent to api.wave.com (Wave's official API host)

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const WAVE_API_BASE = 'https://api.wave.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const json = (body: unknown, status: number) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });

const digitsOnly = (s: string) => s.replace(/[^0-9]/g, '');

const phonesMatch = (input: string, stored: string) => {
  const a = digitsOnly(input);
  const b = digitsOnly(stored);
  if (a.length < 7 || b.length < 7) return false;
  return a.endsWith(b) || b.endsWith(a);
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  let payload: { order_number?: string; phone?: string; origin?: string };
  try {
    payload = await req.json();
  } catch {
    return json({ error: 'Invalid request body' }, 400);
  }

  const ref = (payload.order_number ?? '').trim().toUpperCase();
  const phone = (payload.phone ?? '').trim();
  const originUrl = (payload.origin ?? '').trim();
  if (ref.length < 6 || ref.length > 32 || phone.length < 7 || phone.length > 32) {
    return json({ error: 'Invalid order reference or phone number.' }, 400);
  }
  if (!/^https?:\/\//.test(originUrl) || originUrl.length > 200) {
    return json({ error: 'Invalid return URL.' }, 400);
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  const { data: order, error: orderError } = await supabase
    .from('orders')
    .select('order_number, customer_phone, total, payment_status')
    .eq('order_number', ref)
    .maybeSingle();

  if (orderError) return json({ error: 'Could not start Wave payment. Please try again.' }, 500);
  if (!order || !phonesMatch(phone, order.customer_phone)) {
    return json({ error: 'No order found for that reference and phone number.' }, 404);
  }
  if (order.payment_status === 'paid') {
    return json({ error: 'This order is already paid.' }, 409);
  }

  const apiKey = Deno.env.get('WAVE_API_KEY');
  if (!apiKey) {
    return json(
      { error: 'Wave payment is not set up yet — please pay on pickup or delivery instead.' },
      503
    );
  }
  const currency = Deno.env.get('WAVE_CURRENCY') ?? 'GMD';

  // Create the checkout session at Wave's official API host
  const res = await fetch(`${WAVE_API_BASE}/v1/checkout/sessions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: order.total,
      currency,
      client_reference: order.order_number,
      success_url: `${originUrl}?payment=success&ref=${order.order_number}`,
      error_url: `${originUrl}?payment=error&ref=${order.order_number}`,
    }),
  });

  if (!res.ok) {
    // Wave error details stay server-side; the API key is never logged or returned
    return json(
      { error: 'Could not start Wave payment. Please try again or pay on pickup.' },
      502
    );
  }

  const session = (await res.json()) as Record<string, unknown>;
  const checkoutUrl = (session.wave_launch_url ?? session.url ?? session.launch_url) as
    | string
    | undefined;
  const sessionId = session.id as string | undefined;
  if (!checkoutUrl || !sessionId) {
    return json(
      { error: 'Could not start Wave payment. Please try again or pay on pickup.' },
      502
    );
  }

  const { error: updateError } = await supabase
    .from('orders')
    .update({ payment_method: 'wave', payment_status: 'awaiting', wave_session_id: sessionId })
    .eq('order_number', order.order_number);

  if (updateError) return json({ error: 'Could not start Wave payment. Please try again.' }, 500);

  return json({ checkout_url: checkoutUrl, session_id: sessionId }, 200);
});
