// Edge Function: wave-webhook
// Receives Wave payment events and marks the matching order as paid or failed.
// If WAVE_WEBHOOK_SECRET is configured, the HMAC-SHA256 hex signature of the
// raw request body must match the wave-signature / x-wave-signature header.
// Without the secret, events are still accepted — configure the secret in the
// Wave developer portal once available to enforce verification.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const json = (body: unknown, status: number) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });

const enc = new TextEncoder();

async function hmacSha256Hex(secret: string, body: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(body));
  return Array.from(new Uint8Array(sig), (b) => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const raw = await req.text();

  const secret = Deno.env.get('WAVE_WEBHOOK_SECRET');
  if (secret) {
    const provided = (
      req.headers.get('wave-signature') ?? req.headers.get('x-wave-signature') ?? ''
    ).replace(/^sha256=/, '');
    const expected = await hmacSha256Hex(secret, raw);
    if (provided !== expected) return json({ error: 'Invalid signature' }, 401);
  }

  let event: Record<string, unknown>;
  try {
    event = JSON.parse(raw);
  } catch {
    return json({ error: 'Invalid JSON' }, 400);
  }

  const data = (event.data ?? event) as Record<string, unknown>;
  const reference = data.client_reference ?? event.client_reference;
  const sessionId = data.id ?? data.checkout_session_id ?? event.id;
  if (!reference && !sessionId) return json({ received: true, ignored: true });

  const type = String(event.type ?? event.event ?? '').toLowerCase();
  const paymentStatus = String(data.payment_status ?? event.payment_status ?? '').toLowerCase();
  const succeeded =
    paymentStatus === 'succeeded' ||
    paymentStatus === 'paid' ||
    type.includes('succeed') ||
    type.includes('complete');
  const failed =
    paymentStatus === 'failed' ||
    type.includes('fail') ||
    type.includes('expire') ||
    type.includes('cancel');
  if (!succeeded && !failed) return json({ received: true, ignored: true });

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  let query = supabase.from('orders').update({ payment_status: succeeded ? 'paid' : 'failed' });
  query = reference
    ? query.eq('order_number', String(reference))
    : query.eq('wave_session_id', String(sessionId));

  const { error } = await query;
  if (error) return json({ error: 'Update failed' }, 500);

  return json({ received: true });
});
