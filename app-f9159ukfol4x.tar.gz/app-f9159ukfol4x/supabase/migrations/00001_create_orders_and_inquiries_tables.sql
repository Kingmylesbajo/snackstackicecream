create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null,
  customer_phone text not null,
  delivery_method text not null default '自取',
  address text,
  note text,
  items jsonb not null default '[]'::jsonb,
  total numeric(10,2) not null default 0,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.cake_inquiries (
  id uuid primary key default gen_random_uuid(),
  inquiry_number text not null unique,
  customer_name text not null,
  customer_phone text not null,
  cake_size text,
  flavor text,
  needed_date date,
  description text,
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;
alter table public.cake_inquiries enable row level security;

create policy orders_anon_insert on public.orders for insert to anon with check (true);
create policy orders_anon_select on public.orders for select to anon using (false);
create policy orders_anon_update on public.orders for update to anon using (false) with check (false);
create policy orders_anon_delete on public.orders for delete to anon using (false);
create policy orders_auth_insert on public.orders for insert to authenticated with check (true);
create policy orders_auth_select on public.orders for select to authenticated using (false);
create policy orders_auth_update on public.orders for update to authenticated using (false) with check (false);
create policy orders_auth_delete on public.orders for delete to authenticated using (false);

create policy inquiries_anon_insert on public.cake_inquiries for insert to anon with check (true);
create policy inquiries_anon_select on public.cake_inquiries for select to anon using (false);
create policy inquiries_anon_update on public.cake_inquiries for update to anon using (false) with check (false);
create policy inquiries_anon_delete on public.cake_inquiries for delete to anon using (false);
create policy inquiries_auth_insert on public.cake_inquiries for insert to authenticated with check (true);
create policy inquiries_auth_select on public.cake_inquiries for select to authenticated using (false);
create policy inquiries_auth_update on public.cake_inquiries for update to authenticated using (false) with check (false);
create policy inquiries_auth_delete on public.cake_inquiries for delete to authenticated using (false);