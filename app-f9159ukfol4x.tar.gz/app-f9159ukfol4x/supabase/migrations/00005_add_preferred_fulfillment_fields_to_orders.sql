ALTER TABLE public.orders ADD COLUMN preferred_date date;
ALTER TABLE public.orders ADD COLUMN preferred_time_slot text;