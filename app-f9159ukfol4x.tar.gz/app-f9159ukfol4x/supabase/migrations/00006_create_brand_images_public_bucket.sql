INSERT INTO storage.buckets (id, name, public) VALUES ('brand-images', 'brand-images', true);

CREATE POLICY "brand_images_public_read" ON storage.objects FOR SELECT TO public USING (bucket_id = 'brand-images');